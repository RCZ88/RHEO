Git pitfall: `git add -A` picks up build artifacts (e.g., dist-tmp/) that can exceed Git's 10MB file limit and block the commit. Fix: add the build output dir to .gitignore, then `git rm --cached -r <dir>` to untrack it, then re-stage. Check for large files before committing: `git diff --cached --name-only | while read f; do sz=$(stat -c%s "$f" 2>/dev/null || echo 0); if [ "$sz" -gt 10485760 ]; then echo "$sz $f"; fi; done`
§
MSYS/Windows server startup: `&` backgrounding fails (non-tty bash kills process on tool return), `bun` is missing, `localhost` may not resolve — use PowerShell `Start-Process node` with `$env:PORT` set in same invocation, then curl the LAN IP (e.g. 10.81.99.28) to verify.
§
Windows: no `tee` in PowerShell npm scripts; use `Tee-Object` or `.ps1` launchers. Kill port before starting dev server.
§
Never silently start servers; give copy-paste commands/scripts only. If user says 'I don't see changes', verify fresh build/screenshot.
§
Media capture: confirm subject first (desktop app vs landing website vs mobile app). Playwright `electron` not exported on this Windows install; fallback to OS-level tools.
§
Deliver one clean script; don't iterate 5+ rounds fixing the same script inline.