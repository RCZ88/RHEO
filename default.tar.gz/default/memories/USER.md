User requires EXHAUSTIVE commit messages — every modified file listed individually with its purpose, organized by category. Vague groupings rejected. Hard workflow rule.
Clement Zhao — works on RHEO (Electron + React + Vite app, never TURGO). Based in SE Asia (UTC+07:00). Direct, action-oriented; expects implementation over explanation. Has a cat. Prefers action over explanation.
Pushes back on imprecise file-location claims. Always verify exact paths before stating where results live.
Domain rule: Overlay sessions ALWAYS belong to an episode. episodeId REQUIRED, not optional. Overlays never standalone.
NO GIT CHECKOUT COMMANDS — only read-only git (diff/show). Physical backup at C:/Users/cleme/AppData/Local/hermes/backups/AppTracker-20260831/.
§
Clement Zhao — works on RHEO (Electron + React + Vite app, never TURGO). Based in SE Asia (UTC+07:00).
§
Domain rule: Overlay sessions ALWAYS belong to an episode. episodeId is REQUIRED, not optional. Overlays are never standalone.
§
Prefers action over explanation. Rebukes 'let me explain' / 'investigation ongoing' — wants direct implementation. Saying 'I'll do X' then doing it is correct; narrating intent before acting is not.
§
Pushes back on imprecise file-location claims. Always verify exact paths before stating where results live.