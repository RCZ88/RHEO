---
name: design-audit
description: "Audit frontend design drift before writing a design system."
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
tags: [design, audit, frontend, tokens, consistency, css, tailwind, react, electron, slop]
related_skills: [design-md, claude-design, frontend-component-sourcing, dogfood, font-selection]
metadata:
  hermes:
    tags: [design, audit, frontend, tokens, consistency, css, tailwind, react, electron, slop]
    related_skills: [design-md, claude-design, frontend-component-sourcing, dogfood]
---

# Design Audit (read-only, code-grounded)

Use this skill when a frontend codebase shows visual drift — "every page feels like its own theme", "AI slop", inconsistent colors/components — and someone wants to FIX it with a real design system instead of guessing. The audit is the evidence-gathering prerequisite to authoring a DESIGN.md constitution (see `design-md`). It is strictly READ-ONLY: produce findings, change nothing.

## When to use
- "Audit the design of this app before we write the design system."
- "Why does every page look different?" — need data, not opinions.
- Grounding a DESIGN.md / token spec in reality instead of assumptions.
- Pre-refactor check: quantify how much drift actually exists (slop index).

## When NOT to use
- Actively building a new component/artifact → `claude-design` or `frontend-component-sourcing`.
- QA / bug testing of a running app → `dogfood`.
- The user just wants the spec file → `design-md` (but run this audit first if the codebase already exists and may have drifted).

## The 10-point audit skeleton
1. **Stack census** — framework+version, styling system (Tailwind v3/v4, CSS modules, inline), component lib, chart lib(s), icon source, font-loading mechanism, Electron version, custom vs native titlebar.
2. **Color census** — grep all hex/`rgba()` literals; cluster hues vs grays; build a color-debt table (concern | hues | example hexes | intent). Count one-off (single-use) hex.
3. **Page/route inventory** — every route/window with name, purpose, current visual treatment. Note whether accent/theme systems are actually wired (e.g. `data-page` selectors that no route sets = a dead system).
4. **Typography** — families actually rendered (not just loaded), full size inventory, whether tabular-nums are used for data.
5. **Component divergence** — count canonical-vs-duplicate implementations of card/button/input/badge/tabs/empty-state; name the canonical one; duplication map.
6. **Existing design docs** — locate DESIGN.md / DESIGN_SYSTEM / tokens files; report staleness with specific mismatches (declared font not loaded, banned style present in code, etc.).
7. **Data-viz** — every categorical color mapping (charts, categories, tabs); chart types and libraries in use; shared-wrapper coverage.
8. **Motion** — durations, easings, springs; infinite/ambient loops (battery relevance for all-day apps).
   **Correctness over presence:** for scroll-driven reveals, distinguish a PROGRESS-BOUND implementation (framer-motion `useTransform(scrollYProgress,[a,b],...)`, `useScroll`/`useSpring`) — which is reversible (plays forward AND backward) — from a ONE-SHOT tween (`whileInView`/`animate`, `setInterval` loop) that only ever plays forward. The one-shot-masquerading-as-scrub is the signature AI-builder defect; flag it. See `references/landing-draft-audit.md` §2 for the concrete checks (backward-counting counters, ridgeline crossfade-vs-morph, word-by-word reveal, RM leaks).
9. **Terminology** — exact product/feature/menu/view names as strings (the doc must speak the product's vocabulary, not generics).
10. **Slop index** — summary counts (distinct hues, font families, button styles, radius values, shadow styles, easing curves, one-off hexes) + output doc with tables + screenshot index.

## Technique (static grep census)
See `references/static-audit-recipe.md` for copy-paste commands. Core moves:
- Color census: `grep -rEoh "#[0-9a-fA-F]{3,8}" src | sort | uniq -c | sort -rn` and same for `rgba?([^)]*)`. Save to a file; `awk '$1==1'` = one-off debt; `awk '$1>=10'` = committed set.
- Route inventory: grep `Route path=` / `path="…"` in the router file.
- Token-layer conflict: grep each token file's variable names against `src/` consumption (`grep -rEoh "var(--hairline)" src | wc -l`). A token file imported but consumed 0× = a dead constitution.
- Component divergence: `grep -rln "export.*function GlassCard" src | wc -l`.
- Motion loops: `grep -rEoh "infinite" src | wc -l`; distinct easings: `grep -rEoh "cubic-bezier\([^)]*\)" src | sort | uniq -c`.
- **Typography & fonts: load the `font-selection` skill before choosing any font.** The `font-selection` skill's render-and-look loop (shortlist from `references/font-library.md` → build_preview.py render with real project copy → screenshot/visual check) is mandatory — never commit to a font by name-association alone. See the font-selection skill for the full workflow. This is a first-class step in every design audit and every UI generation pass.
- **Verify the skills registry BEFORE trying to load DESIGN skills.** Call `skills_list` first. If `skill_view(name)` returns "not found" for a DESIGN skill listed in `agent/skills/skill-router/SKILL.md` §3, the skill is curator-managed under `agent/skills/<name>/SKILL.md` — NOT in the registry — and must be read with `read_file('agent/skills/<name>/SKILL.md')`. Do NOT conclude the skill is missing; it is just not registered. Verify by globbing `agent/skills/*/SKILL.md` and diffing against the router's §3 mapping. See `references/skill-router-loading.md`.

## Pitfalls
- **Terminal blocklist on large commands.** In some deployments the inline command parser HARD-BLOCKS oversized/malformed payloads (heredocs, giant one-liners, and especially patterns containing `#` such as hex-color greps). Symptom: `BLOCKED (hardline): command parser limit or malformed executable payload`. Fix: split into small single-purpose `terminal` calls — one grep per call; avoid `#`-literal loops (replace with `awk` post-processing on a saved file, or grep each hex on its own line). Do NOT retry the same giant command.
- **Read-only discipline.** Never "improve" while auditing. The deliverable is a doc, not a diff. Modifying code mid-audit contaminates the evidence.
- **Fetch hygiene (curl body blocked).** In some Hermes shell contexts `/tmp` and `AppData\Local\Temp` reject curl download bodies even though `touch` succeeds there. Symptom: `curl -fsSL -o /tmp/f.tar.gz <url>` exits 0 but the file is 0 bytes or missing. Fix: write scratch to the CWD (repo root) or another verified-writable location, then confirm with `ls -la <file>` + `head -c 4 <file> | xxd` (gzip magic `1f8b`) before extracting. This hit when fetching the Magic UI and React Bits tarballs for the landing-page component sourcing.
- **Screenshot gap → CLOSE IT for web drafts.** For a marketing/landing page you can usually RENDER it, not just flag the gap. An imported draft is often not runnable as-imported (no `node_modules`, no `.next`/`.next` build) — run the package-manager install; that deliverable-not-runnable state is itself a finding. If the default port (`:3000`) is taken by an unrelated server, boot on a free port (`next dev -p 3100`) instead of killing processes you don't own. Screenshot full-page + per-section at 1280×800 AND 375 with Playwright (locate the Python interpreter that actually has the `playwright` module — the CLI and the importable module may live under different interpreters; Chromium is usually already in `~/.cache/ms-playwright`). Vision-review for overflow/clip/overlap. Pinned scrub sections (300vh/150vh sticky) read as "voids" in a still — that's expected scroll runway, not a bug. Full-page stitch at 375px can falsely read as "near-black text"; verify contrast on per-section shots, not the stitch. Never fabricate visual findings.
- **The named spec may not exist.** When the task cites spec files (`design/LANDING_DESIGN_SPEC.md`, `docs/motion_patterns.md`, `docs/perf_playbook.md`), VERIFY they're on disk first — they're often MISSING while a DIFFERENT design's spec IS present (audit the wrong one and the whole pass is wasted). If absent: don't invent it. Flag as the #1 finding, then reconstruct the contract baseline from the draft's OWN artifacts (its `worklog.md` + `globals.css` `@theme` §1 token allowlist) and the task message's explicit requirements. Gate every "missing vs spec" call with "(spec undefined — unverifiable)". Full technique in `references/landing-draft-audit.md`.
- **Conflicting token layers.** Large apps accumulate 2–4 "single source of truth" files (DESIGN.md, DESIGN_SYSTEM.md, tokens.css, implicit index.css). Report each and which one components actually read. The unused one is the trap — e.g. a LAMINAR `tokens.css` imported first in `main.tsx` but consumed 0× in components.
- **Fix-then-verify loop (mandatory).** After each fix batch, RE-RUN the color census grep on the specific files you changed — do NOT assume the batch is clean. Raw hex and `rgba()` literals routinely survive in files adjacent to the ones you fixed (e.g., fixing `GapFillModal` but missing `focusHelpers.ts` GROUP_ACCENTS, or `FocusTimer.tsx` ring colors). The audit is NOT done until `grep -rEoh "#[0-9a-fA-F]{3,8}|rgba?\(" src/` returns zero hits in the modified files AND zero gradient-decorative patterns (`bg-gradient-to-r`, `linear-gradient`) remain on chrome surfaces. See `references/post-fix-verification.md` for the exact commands.
  - **Hex-color grep blocklist workaround:** some Hermes shell deployments HARD-BLOCK `#`-containing hex greps with `BLOCKED (hardline)`. When this happens, grep each hex on its own line without the `#` prefix, or save the census to a file and post-process with `awk`. Do NOT retry the same blocked command — change the shape. See `references/post-fix-verification.md` for the workaround.
  - **Hex-color grep blocklist workaround:** some Hermes shell deployments HARD-BLOCK `#`-containing hex greps with `BLOCKED (hardline)`. When this happens, grep each hex on its own line without the `#` prefix, or save the census to a file and post-process with `awk`. Do NOT retry the same blocked command — change the shape.
  See `references/post-fix-verification.md` for the exact commands.
- **Terminal blocklist on large commands.** In some deployments the inline command parser HARD-BLOCKS oversized/malformed payloads (heredocs, giant one-liners, and especially patterns containing `#` such as hex-color greps). Symptom: `BLOCKED (hardline): command parser limit or malformed executable payload`. Fix: split into small single-purpose `terminal` calls — one grep per call; avoid `#`-literal loops (replace with `awk` post-processing on a saved file, or grep each hex on its own line). Do NOT retry the same giant command.
- **Declared ≠ rendered.** Docs say "Geist primary font" but it's absent from the font `<link>`; per-page accent maps keyed to obsolete route names that no route sets. Always verify a declared system is actually wired before crediting it.

## Output
Write `docs/design_audit.md` (or project-equivalent) containing: all 10 sections as tables, a color-debt table, a slop-index summary block, a screenshot index (captured vs not), and an ending of (a) top-5 highest-leverage inconsistencies, (b) what's worth KEEPING, (c) questions unanswerable from code alone (product-name decision, light-mode status, build-and-screenshot pass).

## Relationship to other skills
- Precedes `design-md`: the audit's (a)/(b)/(c) directly seed the constitution.
- Complements `claude-design` (taste/process for new artifacts) and `frontend-component-sourcing` (real components once the system exists).
- Distinct from `dogfood` (runtime QA) — this is static, pre-change evidence.

## Imported-draft / landing-page variant
When the subject is a marketing/landing page imported from an external AI builder (missing spec, non-runnable repo, scroll-scrubbed animations), use `references/landing-draft-audit.md` for the extended playbook: spec-existence check, reversible-vs-one-shot motion correctness, §1-allowlist color grep, actual Playwright render at 1280/375, and the LOCAL-vs-GLM-EXTRACT work-order verdict.