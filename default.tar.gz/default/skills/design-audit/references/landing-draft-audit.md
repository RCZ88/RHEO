# Auditing an imported AI-builder web draft (Landing / marketing page)

Condensed technique for the "AUDIT ONLY a rough draft imported from an external AI builder"
class of task. Extends the 10-point skeleton in SKILL.md with the parts that are specific to a
marketing/landing page whose spec may be missing and whose repo may not be runnable as-imported.

## 0. Verify the spec actually exists BEFORE auditing
- The task will name spec files (e.g. `design/LANDING_DESIGN_SPEC.md`, `docs/motion_patterns.md`,
  `docs/perf_playbook.md`). **Grep/find for them first.** It is common for these to be MISSING
  from disk while a different design's spec IS present (e.g. `rheo-landing/LANDING_DESIGN_SPEC.md`
  "The Loom" vs the actual draft's "LAMINAR" components). Auditing the wrong spec wastes the whole pass.
- If the named spec is absent: do NOT invent it. Flag it as the #1 finding, then reconstruct the
  contract baseline from the draft's OWN artifacts:
  - the draft's `worklog.md` (often cites a "spec §1/§5" that was never committed),
  - the draft's `globals.css` `@theme` / token block (the §1 allowlist of surfaces/hairlines/text/
    accent — this is the real color contract),
  - the explicit requirements stated in the task message itself.
- Gate every "missing vs spec" judgement with "(spec undefined — unverifiable until restored)".
- Map the task's section names to actual component files. S0–S8 style lists usually map 1:1 to
  `src/components/<X>/Section.tsx` etc. Confirm the mapping before diffing.

## 1. Section diff — present / complete / degraded / absent
For each required section: is the component present, does it implement the stated intent, and is
anything degraded vs the (reconstructed) spec? List specifics, don't just tick a box.

## 2. Motion diff — PRESENCE is not enough; check CORRECTNESS
The classic AI-builder failure is **a one-shot tween masquerading as a scroll-scrubbed reveal**.
For every required animation, classify:
- IMPLEMENTED + correct: bound to scroll progress (e.g. framer-motion `useTransform(progress,[a,b],...)`,
  `useScroll`/`useSpring`), so it plays FORWARD AND BACKWARD (reversible).
- WRONG: a `whileInView`/`animate` one-shot tween that cannot reverse, or a `setInterval` loop that
  only ever plays forward.
- MISSING: not present at all.
Concrete checks that caught real state this session:
- "Backward-counting counters" → confirm the counter is `round(progress * total)` driven by the
  spring progress value; on scroll-up the value DECREASES (reversible). A `setState` tween is wrong.
- "Ridgeline crossfade" (chaotic→calm) → confirm TWO distinct path sets whose OPACITY is
  crossfaded by progress (NOT a single path `d` that morphs). Morphing is a different (cheaper,
  often wrong) effect. The draft's ActFlow ships two full path sets (`calmPath`/`chaosPath`)
  opacity-crossfaded via `useTransform(scrollYProgress,[0,1],[1,0]/[0,1])` — a correct implementation.
- "Word-by-word reveal" → each word's opacity is `useTransform` of its slice of `scrollYProgress`;
  fully reversible.
- Reduced-motion: confirm scrubs collapse to static panels (spec "stacked static panels") and that
  loops are killed. Watch for ONE leak: a live clock that still ticks under `prefers-reduced-motion`
  when the spec says static.

## 3. Color audit — grep vs the §1 allowlist, not vs "hue in general"
- Extract the allowlist from the draft's `globals.css` `@theme` (surfaces, hairlines as white-alpha
  rgba, text ramp, single accent).
- `grep -rEohi "#[0-9a-f]{3,8}|rgba?\([0-9.,\s]+\)$" src --include=*.tsx --include=*.ts --include=*.css`
  then `sort | uniq -c | sort -rn`.
- Off-list hex are usually harmless IF they live in an UNMOUNTED component (e.g. a shadcn
  `ui/chart.tsx` Recharts wrapper the page never renders). Confirm the component is actually mounted
  before flagging a color violation. Dead shadcn `ui/*` wrappers are also bundle bloat → recommend deletion.
- No hue anywhere = pass. White-alpha hairlines/sheens/blooms at ≤8% are LAMINAR-legal.

## 4. Layout audit — actually RENDER it (don't stop at "needs a server")
The base skill says "flag the screenshot gap." For a web draft you can usually CLOSE it:
- The imported draft is often NOT runnable as-imported: no `node_modules`, no `.next`/`.next` build.
  Run the package manager install (npm/pnpm/bun) — this itself is a finding (delivered-not-runnable).
- Port conflict: if `:3000` is already taken by an unrelated server, don't fight it — boot on a free
  port (`next dev -p 3100`). Don't kill processes you don't own.
- **Fetch hygiene:** in some Hermes shell contexts `/tmp` and `AppData\Local\Temp` reject curl download
  bodies even though `touch` succeeds there — write scratch to the CWD (repo root) or another
  verified-writable location, then confirm with `ls -la` + `head -c 4 | xxd` (gzip magic `1f8b`)
  before extracting. This hit when fetching the Magic UI and React Bits tarballs for component sourcing.
- Screenshot with Playwright. The `playwright` CLI and the importable Python `playwright` module
  may live under DIFFERENT Python interpreters — locate the interpreter that actually has the
  module (`python -c "import playwright"`) and call THAT explicitly. Chromium binary is usually
  already in `~/.cache/ms-playwright`.
- Capture full-page + per-section at desktop (1280×800) AND mobile (375). A common bug class is
  375px horizontal overflow / equation-line clipping — verify the fix is present in code.
- Vision-review each shot: overflow, clipping, overlap, voids. NOTE: a full-page-stitch screenshot
  at 375px downscales each section to a thin strip and can falsely read as "near-black text" —
  verify contrast on the per-section shots, not the stitch.
- Intentionally-pinned scrub sections (300vh/150vh sticky) look like "voids" in a still — that's
  expected scroll runway, not a bug. State it so a reviewer doesn't mis-file it.

## 5. Work-order output
End with a table: item | section | severity (BLOCKER/MAJOR/MINOR) | fix owner (LOCAL vs
GLM-EXTRACT) | effort (S/M/L). Then a VERDICT: is any item structural enough to justify ONE GLM
extraction prompt? Typical outcome for a faithful imported draft: structure/motion are fine →
GLM only for COPY/CONTENT; everything else is a deterministic LOCAL punch-list. Do NOT run a
structural GLM extraction that could regress correct reversible-scrub code.

## 6. Component sourcing shape caveats (when fetching real components for missing slots)
When the audit identifies gaps where a real component should be fetched rather than built from scratch,
verify the component's actual shape against the draft BEFORE importing. Three shape mismatches surfaced
in the 2026-08-31 sourcing pass and recur often enough to document:

1. **Magic UI `AnimatedBeam` is a two-ref hero connector, not a standalone wave.** It assumes a *hero
   layout* connecting two named DOM refs (`fromRef`/`toRef`) and ships a hardcoded orange→purple
   gradient (`#ffaa40`→`#9c40ff` — a hue violation out of the box). Do NOT drop it into a
   single-wave area (e.g. an ActFlow ridgeline zone) without (a) stripping the gradient to
   `currentColor`/white, (b) decoupling from the ref-pair layout into a standalone SVG path, and
   (c) accepting it overlaps — not extends — whatever crossfaded wave paths already exist. If you
   want a "beam" element, repurpose the existing wave `d` paths rather than importing `AnimatedBeam`.
2. **Magic UI `BentoGrid` is heavy chrome, not LAMINAR.** The real component uses `box-shadow` +
   `dark:[box-shadow:0_-20px_80px_-20px_#ffffff1f_inset]` and neutral-700/400 text — glassmorphism +
   color, not LAMINAR hairlines + white. The draft's own capability cards are already a cleaner LAMINAR
   take. Only steal the grid-column logic, not the chrome.
3. **React Bits `ScrollVelocity` is a text-scroller, not the SVG wave the draft already has.**
   Duplicate spans + baseVelocity×velocityFactor. The draft's marquee (`Manifesto.tsx`/`TrustedBy.tsx`)
   uses a CSS `translateX(-50%)` loop with `marquee-paused` — simpler and already pause-on-offscreen.
   `ScrollVelocity` is redundant unless you specifically want scroll-coupled text speed.
