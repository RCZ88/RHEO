# Post-Fix Verification

Run after each design fix batch to confirm the patch is clean before moving on.

## Verify no raw hex/rgba remains in modified files

```bash
# Run on the specific files you changed — NOT the whole src/ (avoids blocklist):
grep -rEoh "#[0-9a-fA-F]{3,8}|rgba?\(" src/path/to/changed/file.tsx | sort | uniq -c

# If the command is BLOCKED (hardline) because of the # in the pattern:
# Workaround: grep each hex on its own line without the # prefix, or
# save to a file and awk: grep -rEoh "[0-9a-fA-F]{3,8}" src/... | sort | uniq -c
```

Expected: zero hits in the modified files.

## Verify no decorative gradients on chrome surfaces

```bash
grep -rn "bg-gradient-to-r\|bg-gradient-to-l\|bg-gradient-to-t\|bg-gradient-to-b\|linear-gradient" src/path/to/changed/file.tsx
```

Expected: zero hits. Gradient-decorative patterns (`bg-gradient-to-r`, `linear-gradient`) must not remain on chrome surfaces (buttons, bars, top accents, timeline bars, card borders).

## Verify the fix batch is complete

- All raw hex values in the changed files are mapped to CSS tokens from `src/index.css` `@theme`.
- All `rgba(...)` fallbacks are replaced with `var(--semantic-token)` or `var(--page-accent)`.
- All decorative gradients are replaced with solid `var(--page-accent)` or `var(--semantic-token)`.

If any raw hex, rgba, or gradient-decorative pattern remains, the audit is NOT done. Re-fix before proceeding.
