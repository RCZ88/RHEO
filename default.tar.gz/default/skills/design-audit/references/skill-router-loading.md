# Skill-Router DESIGN Loading Pattern

> Session note: 2026-08-31. The skill router at `agent/skills/skill-router/SKILL.md`
> mandates ALL 8 DESIGN skills for any UI work, but these skills live under
> `agent/skills/<name>/SKILL.md` and are **NOT** registered in Hermes's
> `available_skills` registry. `skill_view(name)` silently returns "not found" for
> them — they must be read directly.

## The problem

`skill_view(name='frontend-design')` → `Skill 'frontend-design' not found`.
`skill_view(name='design-md')` → works (it IS registered).

The DESIGN skills in `agent/skills/` (frontend-external-infra, frontend-design,
Human-Centric UX, Impeccable, Motion-alive, Design Taste System, UI UX Pro Max,
font-selection, beautiful-charts, google-stitch) are **not** in the registry.

## Verification before loading

```bash
# Glob all skill files and diff against the router's §3 mapping:
find agent/skills -name "SKILL.md" | sed 's|agent/skills/||; s|/SKILL.md||' | sort
# Compare against skill-router/SKILL.md §3 scenario-to-skill mapping.
```

## Loading pattern

Read each SKILL.md directly:
```python
# Use read_file on the absolute path:
# agent/skills/frontend-external-infra/SKILL.md
# agent/skills/frontend-design/SKILL.md
# agent/skills/Human-Centric UX/SKILL.md
# agent/skills/impeccable/SKILL.md
# agent/skills/motion-alive/SKILL.md
# agent/skills/design-taste/SKILL.md
# agent/skills/ui-ux-pro-max/SKILL.md
# agent/skills/font-selection/SKILL.md
```

Order per the router §3 DESIGN section:
1. frontend-external-infra (MANDATORY — MCP inventory + anti-slop)
2. frontend-design (MANDATORY — DeskFlow tokens, page patterns)
3. Human-Centric UX (MANDATORY — 4-state coverage)
4. Impeccable (MANDATORY — 7 domains, 23 commands)
5. Motion-alive (MANDATORY — liveliness levels)
6. Design Taste System (MANDATORY — knobs, aesthetic matrix)
7. UI UX Pro Max (MANDATORY — industry rules)
8. font-selection (MANDATORY for typography decisions)

## Pitfall

Do NOT rely on `skill_view` for DESIGN skills — it will silently fail and you'll
skip mandatory skills. The router's own anti-pattern rule: "NEVER load only 2
skills. The user has raged about this repeatedly. ALL 8 MANDATORY skills must be
loaded for ANY UI work."

## Note on `skill-router/SKILL.md` itself

The router exists at `agent/skills/skill-router/SKILL.md`. It IS referenced by
the user and is the source of truth for load order. It is also NOT in Hermes's
registry — read it directly too.
