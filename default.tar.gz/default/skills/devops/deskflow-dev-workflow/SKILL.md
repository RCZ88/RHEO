---
name: deskflow-dev-workflow
version: "1.0.0"
author: hermes-agent
license: MIT
description: Build/verify and repo pitfalls for the DeskFlow app.
metadata:
  hermes:
    tags: [electron, build, deskflow, rheo, ipc, git-pitfall]
    related_skills: [electron-build, git-workflow]
---

# DeskFlow (RHEO) Dev & Build Workflow

## When to Use
- User asks you to act as a coding agent for the DeskFlow/RHEO Electron app (via `opencode.json` + `AGENTS.md`).
- You are implementing a feature spec (`RESULT.md`) or wiring new IPC channels in this repo.
- `git diff` shows a giant repo-wide change and you must distinguish your real edits from noise.
- You need to build/verify before declaring a task done.

DeskFlow is an Electron productivity/tracking app with AI-agent integration, located at
`C:\Users\cleme\Documents\COMPUTAH_SAYENCE\App Tracker\`. When the user asks you to act as a
coding agent here (via `opencode.json` + `AGENTS.md` + `agent/skills/skill-router`), the
operating contract lives in the repo's `AGENTS.md` — follow its startup ritual and Skill
Router. This skill captures the *engineering* specifics that are easy to get wrong and recur
every session.

## 1. Build & Verify Gate (THE gate — do not skip)
Run the single all-in-one build. It runs all 4 steps (renderer → preload → main services → main entry):

```
node scripts/build.mjs
```

Expected green artifacts (verify these exist + sizes):
- `dist/index.html` — must contain `#root` (black-screen prevention).
- `dist-electron/preload.cjs` — ~120–130 KB.
- `dist-electron/main.cjs` — ~1.5 MB.
- `dist/assets/*.js` — renderer bundle, non-trivial size.

If you only changed renderer TSX, `vite build` (Step 1) is the part that matters; if you
touched `main.ts`, the main-entry step (Step 4) matters; if you touched `preload.ts`, Step 2
(esbuild) matters. Running the whole script is the safe default.

> Note: the three-step manual sequence in AGENTS.md (`vite build` + `esbuild src/preload.ts ...`
> + `node scripts/rebuild-main.mjs`) is now superseded by `node scripts/build.mjs`. Prefer the
> single command — it orchestrates all four phases and is less error-prone.

Verification-after-build: use `search_files` (regex) for `handlerName` in `dist-electron/main.cjs`
and `bridgeName` in `dist-electron/preload.cjs` to confirm your additions compiled in.

## 2. PITFALL — Repo-wide CRLF↔LF git diff is NOISE, not your edits
`git diff` against HEAD routinely shows **185 files / ~21K insertions / ~10K deletions** across
totally unrelated regions. This is a **line-ending flip** (working tree is CRLF `^M$`, HEAD is
LF) caused by `core.autocrlf=true` — almost always a leftover from a prior agent session, NOT
your changes.

Rules:
- Do NOT panic. Do NOT `git checkout/restore/reset --hard/clean` (Zero-Destruction Rule in AGENTS.md).
- Do NOT renormalize or commit it. Your real edits are isolated; verify them with targeted
  `search_files` on the source files you touched, not by reading the giant diff.
- The TypeScript build ignores line endings, so the build is unaffected.
- `git diff --ignore-all-space` will NOT collapse it (content is identical; it's pure EOL).

Correct way to confirm your work is clean: `search_files` for `yourUniqueString` in `src/main.ts`
and check the compiled `dist-electron/*.cjs` for the same string.

## 3. Agentic IPC channel-naming convention
When implementing agentic/agent-to-agent features, use these canonical `deskflowAPI` namespace
NAMES (this is the naming convention — it is NOT a guarantee they are already wired; a prior
session's handoff falsely claimed `agent`/`brain`/`mission` bridges existed when they did not):

| Capability   | Handler (main.ts)            | Preload bridge (deskflowAPI)        |
|--------------|------------------------------|-------------------------------------|
| Agent msgs   | `agent:sendMessage` etc.     | `deskflowAPI.agent.*`               |
| Context brain| `brain:addMemory` etc.       | `deskflowAPI.brain.*`               |
| Missions     | `mission:create` etc.        | `deskflowAPI.mission.*`             |
| Session grps | `session-group:*`            | `deskflowAPI.sessionGroup.*`        |

> PITFALL: a feature spec (e.g. `RESULT.md`) may use DIFFERENT channel names (it used `conductor:*`
> for agent comms). Trust the **actual preload bridges** over the spec doc. Implement against the
> preload-aligned names so handler ↔ bridge ↔ d.ts line up. Add the matching `d.ts` declarations in
> `src/types/deskflow-api.d.ts`.

Hard invariant (AGENTS.md §7): register all IPC handlers at **module top level** in main.ts — never
inside a try/catch — to avoid silent registration failure.

## 4. Pre-implementation audit (avoid trusting handoff docs)
Handoff/workspace markdown (e.g. `workspace29082026.md`) often misreports what already exists
(the prior session's log claimed preload bridges existed that did not, and vice-versa). Before
writing code, `search_files` (regex) the truth:
- Handlers present? search `channel:name` in `src/main.ts`
- Tables present? search `CREATE TABLE IF NOT EXISTS table_name` in `src/main.ts`
- Preload bridge present? search `^\s*(agent|brain|mission):\s*\{` in `src/preload.ts`
- Frontend component present? search `ComponentName` in `src` (`*.tsx`)

Implement only the genuine gaps. In the full-agentic-system task this avoided re-implementing
session-groups/selection-capture (already done) and `assemble-context` brain injection (already done).

## 5. Frontend component conventions
- Panels live in `src/components/<feature>/`. Pages in `src/pages/`.
- Wire new pages as `lazy(() => import(...))` + `<ErrorBoundary><Suspense>` in `App.tsx`, with a
  `<Route path="/feature" ... />`.
- Apply the DeskFlow design system: Tailwind, `rounded-xl`, `p-5`, zinc palette, Lucide icons,
  and cover ALL four states (empty / loading / error / populated) per AGENTS.md §5b.
- Access IPC via `const api: any = (window as any).deskflowAPI;` then `api.<namespace>.<method>(...)`.

## 6. PITFALL — `write_file` FULL-OVERWRITES a paginated read (data-loss trap)
`write_file` **replaces the entire target file** with the content you pass — it is NOT a patch.
If you previously read that file with `read_file` using `offset`/`limit` (pagination), you only
saw a slice. Writing "just the slice you remember" DESTROYS the rest of the file.

Concrete incident (this session): an earlier agent read `DeadlinesCard.tsx` (812 lines) with
`offset`/`limit`, then later called `write_file` with ~20 lines of JSX. The file was truncated
812 → 20 lines (all imports, functions, and state gone). The agent then tried to "recover" with
`git checkout -- src/components/dashboard/DeadlinesCard.tsx` — which is itself a BANNED command
(see §7). Double failure from one bad pattern.

Rules:
- **If you have NOT read the whole file, do NOT `write_file` it.** Read it fully first, OR use
  `patch` (find-and-replace) for surgical edits. `patch` is the safe default for editing any file
  you only partially viewed.
- `write_file` is only for: brand-new files, or files you have fully read in one shot and are
  rewriting wholesale.
- The `write_file` tool itself warns: "was last read with offset/limit pagination (partial view).
  Re-read the whole file before overwriting it." Heed that warning — it means you are about to
  truncate.
- When a write_file-truncation happens: the fix is to `read_file` the file in full, then
  `patch`/`write_file` with the COMPLETE intended content. Never reach for git to undo a content
  edit (see §7).

## 7. ABSOLUTE ZERO-DESTRUCTION RULE — git self-recovery is BANNED (re-enforced)
`AGENTS.md` §0.5 forbids ALL of these under any circumstance, with zero exceptions:
- `git checkout -- .` / `git checkout <path>` / `git restore <path>`
- `git reset --hard` / `git reset --merge`
- `git stash drop` / `git clean -fd` / `git clean -df`
- `git revert` against a range
- ANY git command whose effect is to change working-tree files to match a different history point.

The trap that bites autonomous agents: after you break a file (e.g. via the §6 write_file
truncation), the instinct is `git checkout -- <file>` to "get the good version back." That is the
exact banned action and it ALSO discards any legit uncommitted edits. The correct recovery:
1. Read the file fully; reconstruct via `patch`/`write_file` with complete content.
2. If a genuine undo-to-last-known-good is truly needed, the ONLY sanctioned route is a physical
   backup with explicit user permission (per AGENTS.md §0.5 "ONLY ROUTE: PHYSICAL BACKUP WITH
   EXPLICIT PERMISSION") — never git.
3. For verification of what you changed, use `search_files` on the source + compiled output, NOT
   `git diff`/`git checkout` (and remember the repo-wide CRLF noise from §2 is not your edits).

This rule was violated three times in the handoff session this skill is documenting
(transcript lines 4256/4830/5092 ran `git checkout -- src/components/dashboard/DeadlinesCard.tsx`).
Treat any such command in a continuation/handoff as a red flag to escalate, not to repeat.

## 8. PITFALL — Feature scope: workspace features live in TerminalPage, NOT App.tsx
`App.tsx` is the **app-wide shell** (sidebar, global header, route table). Mounting a feature
there puts it on EVERY page. The DeskFlow **workspace** (`/terminal` → `TerminalPage.tsx`) is a
distinct, scoped surface — features that belong to the workspace MUST be mounted inside
`TerminalPage`, never at the app root.

Concrete correction from this session: the **Selection Engine** was mounted app-wide in `App.tsx`
(`<SelectionProvider>` wrapping the whole app + `<SelectionOverlay>`/`<SelectionToolbar>`/
`<SelectionResultPanel>` + a global toggle button in the header). The user rejected this: the
selection pointer appeared on Dashboard/other pages. Fix = move it entirely into `TerminalPage`:

1. In `App.tsx`: remove the `<SelectionProvider>` wrapper, the `<SelectionEngineActivator />`, the
   three overlay components, and the header toggle button. Drop now-unused imports (e.g.
   `MousePointer2`, the selection-engine import). **Keep** imports still used by App (e.g.
   `VoiceProvider`).
2. In `TerminalPage.tsx`: `import { SelectionProvider, SelectionOverlay, SelectionToolbar,
   SelectionResultPanel, SelectionEngineActivator } from '../features/selection-engine';` — wrap the
   `<PageShell>` content in `<SelectionProvider>`, mount the activator + overlays inside it (before
   `</PageShell>`), and add the toggle button into the workspace terminal tab bar.

Rules of thumb for "where does this mount?":
- If a UI belongs to the agent terminal workspace / workspace sidebar → mount in `TerminalPage.tsx`.
- If it must be reachable from the global nav/route table → wire a lazy `<Route>` in `App.tsx` but
  keep the component body self-contained.
- When in doubt, ask: "should this show on pages other than /terminal?" If no → it is a workspace
  feature.

## 9. PITFALL — Command-palette / ⌘K navigation MUST go through `deepNav`, not bare `navigate()`
The ⌘K palette (`src/components/GlobalSearchCommandPalette.tsx`) is the user's way to jump to
**specific sub-tabs and cards**, not just pages. A recurring breakage: `onNavigate` does only
`navigate(item.target)` where `target` is a bare route (`/activity`). That lands on the page
ROOT — every "feature" entry collapses to the same place and the user sees "navigation doesn't
work / doesn't reach the specific section."

Correct pattern (see `references/deep-navigation.md` for the full API + per-page `tab` intake):
- Give each palette item `{ route, tab?, section?, keywords[], group, icon }`.
- In `App.tsx` `onNavigate`, call `navigateTo({ route, tab, section }, navigate)` from
  `src/lib/deepNav.ts`, then retry `scrollToSection(section)` ~8× with 200 ms backoff
  (the target renders AFTER navigation + tab switch, so a single scroll misses).
- `scrollToSection` is a **no-op unless the target element has `data-section="<id>"`**. If you
  add a palette item with a `section`, you MUST also add the matching `data-section` anchor to
  the target element (Activity/AI/Focus tab containers, etc.). Without it, nav silently lands
  on the page root.
- Pages differ in how they read the `tab` hint: Settings/IDE read `localStorage['<route>-activeTab']`
  on mount; Finance/Insights/Terminal/Focus/Guide/Database read `location.state?.tab` in a
  `useEffect`; Activity reads `?tab=` from the URL search; AI (`/ai`) uses `canvasMode`
  ('canvas'|'deck'|'compositions'), so set `canvasMode` from `location.state?.tab` for AI items.

## 10. PITFALL — `vite build` trips the "long-lived server" guard; run it in background
On this host, invoking `vite build` (or `npm run build`) is flagged as a long-lived
server/watch process and REFUSED in the foreground. Run it backgrounded and read the log:
```
cd "C:/Users/cleme/Documents/COMPUTAH_SAYENCE/App Tracker"
npx vite build > /tmp/vite_build.log 2>&1; echo "EXIT=$?"
# then: process(wait) / read_file /tmp/vite_build.log  -> expect EXIT=0 + "✓ built"
```
`node scripts/build.mjs` (the full 4-phase build, §1) runs fine in foreground. Use `vite build`
for a fast renderer-only check when you only touched TSX.

## 11. PITFALL — lucide-react icon names: validate before importing
Not every intuitive name is exported. `Audit` and `Alarm` are NOT valid lucide-react exports
(the build fails with ``"<Name>" is not exported by "node_modules/lucide-react/dist/esm/lucide-react.js"``).
Before importing an uncommon icon, verify it resolves:
```
node -e "const i=require('lucide-react'); ['Audit','Alarm','ShieldAlert','Bell'].forEach(n=>console.log(n, !!i[n]))"
```
Use `ShieldAlert` for audit-style icons and `Bell` for alarm-style icons (or map them in an
`Icon` alias block). This applies to ANY component file importing from `lucide-react`.

## 12. PITFALL — Commit messages MUST be exhaustive (commit skill, not summary)

The `commit` skill (in this repo at `agent/skills/commit/SKILL.md`) mandates:
- `git add -A` stages ALL files — never partial.
- Before writing the message: run `git diff --cached --stat`, read `agent/state.md` Recent Changes, check `agent/docs/` for PROMPT.md/CONTEXT_BUNDLE.md summaries, check new files in `src/pages|components|services|lib`, check `main.ts` for new `ipcMain.handle`.
- The message MUST cover EVERY modified file and the purpose of each change. "A missing change description is a bug in the commit message."
- NEVER write a short commit message.

Concrete correction from this session: a commit bundling 600 pre-existing uncommitted files plus the handoff fix got a 3-paragraph message that said "etc." and "NOT produced by the handoff work" for the bulk of the files. User rejected this: *"WHY WAS THE COMMIT MESSAGE SO SHORT ON THE PREVIOUS COMMIT?? ITS NOT FOLLOWING HTEP ROCEEDURES OF THE commit skill. FIX IT."*

Rules:
- For a checkpoint commit covering many pre-existing files, group them by directory/component with a bulleted list — name every top-level directory and what it contains. "etc." is not allowed.
- For a feature commit, every file you changed gets a line with its purpose.
- When amending an already-pushed commit, use `git commit --amend -F <file>` then `git push --force-with-lease`.

## 13. PITFALL — TerminalPage `assembleContext` import is broken

`src/pages/TerminalPage.tsx` (line ~4261) historically imported `assembleContext` via a relative path like `await import('../services/ContextService')` or `await import('../../main/ai/userContextService')` — both fail the build because:
- There is no `src/services/ContextService.ts` (context lives in the main process at `src/main/ai/userContextService.ts`, which is not in the renderer's module graph).
- Even the correct main-process path is not resolvable from the renderer bundle.

The sanctioned fix: access it through the preload bridge:
```ts
const api = (window as any).deskflowAPI
if (api?.assembleContext) {
  const rendererContext = await api.assembleContext({ projectId: selectedProject, topic: sessionName, tokenBudget: 2000 })
  ...
}
```
The preload bridge `assembleContext` is defined in `src/preload.ts`. Always prefer the preload bridge over dynamic `import()` for main-process modules from renderer code.

## 14. ARCHITECTURAL INVARIANT — Overlay sessions ALWAYS belong to an episode

The user rejected a design where overlay sessions were standalone items that could be created without an episode. The rule is absolute:

> "proper connection between the overlay and the episodes stuff and series and like how an overlay should be able to be assigned for the episode (IT SHOULD ALWAYS BELONG TO AN EPISODE)"

This means:
- `StudioSession.episodeId` is **REQUIRED** (not optional). The type must not allow `episodeId?: number`.
- The DB table `overlay_sessions` has `episode_id INTEGER NOT NULL` with a foreign key to `content_episodes(id)` ON DELETE CASCADE.
- Importing a video into Overlay Studio requires selecting an episode first. There is no "standalone overlay session" workflow.
- The `content_episodes` table gains `series_id`, `episode_number`, `overlay_session_id`, `caption_track` to support the episode↔series↔overlay hierarchy.
- Series style (visual_style, tone, pacing, frame_mode) is inherited by all episodes in the series, and by extension their overlay sessions. Provide an "apply series style" action in the overlay assignment UI.
- When the user asks to "connect overlay and content creation" or "integrate overlay studio with episodes", this episode-first pattern is the expected design. Do not propose standalone overlay sessions.

This invariant was established in the session that produced the Content Engine ↔ Overlay Studio handoff feature (commits 9e2c86b → 0fcd869).

## References
  diagnosis recipe with copy-paste verification commands.
- `references/deep-navigation.md` — deep-linking architecture: `deepNav.ts` API, per-page `tab`
  intake, the `data-section` anchor requirement, and how to verify a navigation fix.
- `references/workspace-scope.md` — worked recipe for scoping a feature into `TerminalPage` instead of
  the app-wide `App.tsx` shell (Selection Engine example, verification commands).
- `references/safe-file-edits.md` — `write_file` truncation + illegal-git-recovery pitfall, the
  edit decision table, and the Self-page `<CanvasGraph />` crash worked example (see §6/§7).
- `references/brain-visualization-physics.md` — architecture of the brain visualization
  (NeuralFlow + CanvasGraph): curl-noise flow field, SOC cascade engine, depth from z-coordinate,
  half-resolution glow layer, Cajal-line tapering, motion design (L2), and performance.
