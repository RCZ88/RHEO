# Brain Visualization Physics & Architecture (DeskFlow/RHEO)

## What this covers
The Life → Self page brain visualization — `NeuralFlow` (ambient flow field) + `CanvasGraph` (knowledge graph) — was redesigned from generic effects into a unified "neural organism" using physics-based rendering. This reference captures the architecture so future sessions can extend it without re-deriving the science.

## The design concept: "Avalanche" (criticality-driven)
Real cortical networks sit at a **critical point** between order and chaos (Beggs & Plenz 2003, "Neuronal Avalanches"). The visualization models this:

- **NeuralFlow** = *subthreshold* regime (resting hum, like EEG 1/f pink noise — Buzsáki, *Rhythms of the Brain*)
- **CanvasGraph** = *suprathreshold* regime (when a node fires, a signal propagates along edges as an action potential — fast rise, slow decay, Hodgkin-Huxley shape)

Both layers read the same noise field + activity state → one organism, not two widgets.

## File layout
```
src/features/warmth/context-brain/
├── physics/
│   ├── noiseField.ts      — curl-noise (Bridson's technique, divergence-free)
│   └── avalanche.ts       — SOC cascade engine (refractory windows, probabilistic branching)
├── BrainGraph.tsx         — suprathreshold renderer (spike glow, depth, Cajal lines)
├── BrainVisualization.tsx — orchestrator (4 states: empty/loading/error/populated)
├── NeuralFlow.tsx         — REWRITTEN: consumes noise field + biases from live data
└── CanvasGraph.tsx        — legacy (still exists, used by BrainGraph as fallback)
```

## Key techniques

### 1. Curl-noise flow field (`noiseField.ts`)
- Divergence-free: particles never clump or fountain unnaturally
- `sample(x, y, t)` returns normalized direction
- `biasAt(x, y, px, py, radius)` + `aggregateBias()` tie the field to live node positions
- Zero dependencies — pure math

### 2. SOC cascade engine (`avalanche.ts`)
- `computeCascade(originId, nodes, edges, now, magnitude)` → BFS with probabilistic branching
- Refractory window (800ms): a node that just fired can't re-fire → prevents infinite loops
- `shouldReheat(lastMagnitude, lastTime, now)` — criticality-coupled, not wall-clock
- `getNodeGlow(node, now)` — exponential decay over ~1.5s (fast rise, slow decay)

### 3. Depth from z-coordinate
- d3-force-3d computes `z` but the old code discarded it
- New: `depthFactor(node)` maps z (-1..1) → size/opacity scale (0.7..1.2)
- Closer nodes = larger + brighter = real depth perception

### 4. Half-resolution glow layer
- Render glow to a half-res canvas, box-blur, composite with `globalCompositeOperation = 'lighter'`
- Approximates GPU bloom without WebGL dependency
- Performance: O(n) instead of O(n²) for glow

### 5. Tapering Cajal lines
- Particle alpha fades in/out over lifetime: `sin(lifeFrac * π)` → 0→1→0
- Line width tapers: `0.3 + taper * 0.5`
- References Ramón y Cajal's ink drawings of neurons

## Motion design
- **Level: L2 (Responsive)** — L1 too calm, L3 too noisy for a data page
- Two amplitude bands: low continuous ambient + rare high-amplitude avalanches
- The gap between bands IS the information (cascades read as events)
- Reduced motion: static field snapshot, instant state snaps, no traveling pulses

## Performance
- Physics tick: ~12-15fps (interpolated to 60fps render)
- Edges: one pass, no per-frame `ctx.stroke()` loop for glow
- Reheat: proportional to avalanche size, not blind timer
- Web Worker candidate if node count > 300-500

## Integration pattern
- `BrainVisualization` orchestrator owns shared noise field + activity state
- `NeuralFlow` receives `dataPoints` prop (live node positions + strengths)
- `BrainGraph` receives `now` prop for time-based glow calculations
- Both layers read the same `activity` state → unified organism

## Known gotchas
- `React.cloneElement` in production JSX: don't rely on global `React` reference — use spread props instead
- `write_file` truncation: always read full file before rewriting, or use `patch`
- The `z` coordinate from d3-force-3d is roughly -1..1 — clamp depthFactor to avoid extreme scales

## References
- Beggs, J. & Plenz, D. (2003), *Neuronal Avalanches in Neocortical Circuits*
- Buzsáki, G., *Rhythms of the Brain* (1/f pink noise)
- Hodgkin, A. & Huxley, A. (1952) — action potential shape
- Bridson, R., *Curl Noise for Procedural Fluid Flow* (SIGGRAPH)
- Ramón y Cajal, S. — ink drawings of neurons (line quality reference)
- Dunn, G., *Self Reflected* — gold-leaf brain artwork (specular shimmer reference)
