# DeskFlow Build & Verify — Reference

## Single-command build
```
cd "C:/Users/cleme/Documents/COMPUTAH_SAYENCE/App Tracker"
node scripts/build.mjs
```
`scripts/build.mjs` runs 4 phases:
1. `npx vite build` → renderer into `dist/`
2. `npx esbuild "src/preload.ts" --outfile="dist-electron/preload.cjs" --bundle --format=cjs --platform=node --target=node22 --external:electron`
3. esbuild of `src/main/**` service modules → `dist-electron/main/**`
4. Vite library-mode build of the main entry → `dist-electron/main.cjs`

Node in the environment is v24.x; build targets `node22` — works fine.

## Artifact checklist (green build)
| File | Must |
|------|------|
| `dist/index.html` | exist, contain `<div id="root">` |
| `dist-electron/preload.cjs` | ~120–130 KB |
| `dist-electron/main.cjs` | ~1.5 MB |
| `dist/assets/*.js` | non-trivial size (renderer bundle) |

## Confirm your edits compiled in
Use `search_files` (regex) or `grep` for a unique string you added:
- `agent:sendMessage` in `dist-electron/main.cjs` → expect ≥1
- `agent:sendMessage` in `dist-electron/preload.cjs` → expect ≥1
- `agent_messages` in `dist-electron/main.cjs` → expect ≥1 (table DDL)

## CRLF git-diff false positive — diagnosis & correct response
Symptom:
```
git diff --stat        # 185 files changed, 21000 insertions, 10000 deletions
git diff src/main.ts  # thousands of +++/--- in unrelated regions
```
Confirm it's EOL, not content:
```
head -1 src/main.ts | cat -A      # shows ^M$  (CRLF) while HEAD is LF
git config --get core.autocrlf     # "true"
git diff --ignore-all-space src/main.ts | grep -cE '^[+-]'   # still huge -> pure EOL
```
Correct response:
- It is NOT your edits (you likely touched 1–3 files).
- Do NOT `git checkout/restore/reset --hard/clean` — violates Zero-Destruction Rule.
- Do NOT renormalize or commit it.
- Verify your real edits with targeted `search_files`/`grep` on the specific files you changed + the
  compiled `dist-electron/*.cjs` (build ignores line endings, so it's unaffected).
- The diff noise is a leftover from a prior session's working-tree state; leave it alone unless the
  user explicitly asks to renormalize.

## Runtime verification (after build)
Per AGENTS.md §5c: the build is necessary but NOT sufficient. A running process holds the old
`main.cjs` in memory, so the user must FULLY close + relaunch the app before testing. Use Probe MCP
(`probe_open` → `assert_*`/`snapshot`/`read_console`) for real-UI verification rather than only an
IPC probe.
