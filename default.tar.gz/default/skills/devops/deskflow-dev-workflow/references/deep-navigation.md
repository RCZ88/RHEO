# DeskFlow Deep Navigation & Command Palette — Reference

This app has a real deep-linking architecture for the ⌘K / Ctrl+K command palette
(`src/components/GlobalSearchCommandPalette.tsx`). Knowing it prevents the recurring
"navigate to a feature but it only lands on the page root" bug.

## The core rule
`navigate(item.target)` with a BARE route (e.g. `/activity`) lands on the page ROOT —
every "feature" entry collapses to the same page. To reach a specific sub-tab or card you
MUST go through `src/lib/deepNav.ts`.

## deepNav.ts API (`src/lib/deepNav.ts`)
- `navigateTo({ route, section?, tab?, subpage?, state? }, navigate)` — sets a `section`
  hint in `sessionStorage`, a `tab` hint in `localStorage` keyed per-route
  (`<route>-activeTab`, e.g. `settings-activeTab`, `ide-projects-activeTab`,
  `finance-activeTab`, `insights-activeTab`), then calls `navigate(route, { state })`.
- `scrollToSection(sectionId, smooth?)` — `document.querySelector('[data-section="<id>"]')`
  and `scrollIntoView`. Returns boolean.
- `consumeSectionHint()` / `consumeSubpageHint()` — read+delete the sessionStorage hints.
- `useScrollToSection(sectionHint?)` — retries scrollToSection with backoff on mount.

## Wiring a palette entry to a real target
Palette item shape (in `GlobalSearchCommandPalette.tsx`):
```
{ id, label, route, tab?, section?, keywords[], group, icon }
```
- `route` — base route (`/reports`, `/finance`, `/ide`, ...).
- `tab`   — sub-tab key. deepNav writes `localStorage['<route>-activeTab'] = tab`; the page
  reads it on mount (see per-page pattern below).
- `section` — the `data-section` id to scroll to after navigation.

`onNavigate` handler pattern (in `App.tsx`):
```ts
onNavigate={(item) => {
  setPaletteOpen(false);
  navigateTo({ route: item.route, tab: item.tab, section: item.section }, navigate);
  if (item.section) {
    const tryScroll = (n: number) => {
      if (n <= 0) return;
      if (!scrollToSection(item.section!)) setTimeout(() => tryScroll(n - 1), 200);
    };
    setTimeout(() => tryScroll(8), 250); // retry because the tab/section renders late
  }
}}
```
The retry matters: the target page renders after navigation + tab switch, so a single
scroll often runs before the `[data-section]` exists.

## How each page consumes the `tab` hint
- Settings: `useState(... () => localStorage.getItem('settings-activeTab') || 'category')`,
  plus `useEffect` reads `location.state?.tab`.
- IDE: `useState(... () => localStorage.getItem('ide-projects-activeTab') || 'overview')`,
  plus `useEffect` reads `location.state?.tab`.
- Finance/Insights/Terminal/Focus/Guide/Database: `useEffect` reads `location.state?.tab`
  (or `?.group` for Terminal) and calls `setActiveTab`.
- Activity: reads `?tab=` from `window.location.search` (NOT localStorage). Pass
  `tab: 'apps'|'websites'|'productivity'|'focus'`.
- AI (`/ai`): uses `canvasMode` ('canvas'|'deck'|'compositions'), NOT `tab`. Add a
  `useEffect` that reads `location.state?.tab` and sets `canvasMode` if it matches.

## `data-section` anchors are REQUIRED for `section` to work
`scrollToSection` is a no-op unless the target element has `data-section="<id>"`. Concrete
anchors that exist / were added:
- Finance: `finance.overview`, `.wallets`, `.transactions`, `.categories`, `.people`,
  `.budget`, `.charts`, `.subscriptions`, `.subscriptions.full`, `.audit`, `.recap`
- IDE: `ide.overview`, `.environment`, `.projects`, `.git`, `.analytics`, `.backup`, `ide.ai-tools`
- Insights: `insights.day`, `.weekly`, `.activities`, `.recap`
- Settings: `settings.appearance`, `.category`, `.general`, `.tracking`, `.prompts`,
  `.colors`, `.ai`, `.ai.diagnostics`, `.finance`, `.devices`
- Activity: `activity.apps`, `.websites`, `.productivity`, `.focus` (add to the tab's
  `motion.div` container)
- AI: `ai.canvas`, `ai.deck`, `ai.compositions` (add to the mode container `div`)
- Focus: `focus.goals`, `.stats`, `.history` (add to the tab container)

If you add a new palette item with a `section`, you MUST also add the matching
`data-section="<id>"` to the target element, or navigation silently lands on the page root.

## Verifying a navigation fix
1. `vite build` (or `node scripts/build.mjs`) — must exit 0.
2. Grep the compiled bundle for a unique label/string from your new item.
3. Manual: ⌘K → search → select → confirm the page switches tab AND scrolls to the card.
   (No automated UI test exists for this; state the limitation if you can't click live.)
