# Episode-First Overlay Architecture

> Invariant established 2026-08-31 (commits 9e2c86b → 0fcd869). The user explicitly rejected standalone overlay sessions.

## Rule
Overlay sessions **always** belong to an episode. There is no "standalone overlay session" workflow.

## Data Model
```
content_episodes
  ├── id (PK)
  ├── series_id (FK → content_series.id)
  ├── episode_number
  ├── overlay_session_id (FK → overlay_sessions.id, nullable)
  ├── caption_track (JSON)
  └── ...

overlay_sessions
  ├── id (PK, text)
  ├── episode_id (FK → content_episodes.id, NOT NULL, CASCADE)
  ├── name, source_video_path, source_video_name
  ├── transcript, cut_plan, scene_plan (JSON)
  ├── motion_assets (JSON array)
  ├── overlay_plan (JSON — the AI-generated overlay plan from content:edit:overlay-plan)
  ├── caption_track (JSON)
  ├── theme_id (FK → themes.id)
  └── status (linked | transcribing | transcript_ready | ...)

content_series
  ├── id (PK)
  ├── visual_style, tone, pacing, frame_mode
  └── ...
```

## Series → Episode → Overlay Inheritance
- Series defines: `visual_style`, `tone`, `pacing`, `frame_mode`
- Episodes inherit series settings (stored on `content_episodes.series_id`)
- Overlay sessions inherit episode + series context
- UI: "Apply series style" button on each overlay session copies series style into the overlay's `overlay_plan.series_style`

## IPC Channels
| Channel | Purpose |
|---------|---------|
| `overlay:session:create` | Create overlay session (requires episodeId) |
| `overlay:session:get` | Get one session |
| `overlay:session:list` | List sessions (filter by episodeId) |
| `overlay:session:update` | Update session fields |
| `overlay:session:delete` | Delete session (unlinks from episode) |
| `episode:get-overlay` | Get the latest overlay session for an episode |
| `content:episodes:link-overlay` | Persist overlay_session_id on episode |

## Frontend Components
- `OverlayAssignmentPanel.tsx` — panel in episode Assets tab showing overlay sessions
- `EpisodesView.tsx` — fetches series info, passes style to panel
- `OverlayStudioPage.tsx` — import requires episode, loads from backend
- `StudioSidebar.tsx` — shows "Episode #N · name" for each session
- `StudioWorkspace.tsx` — topbar shows "EP #N" badge

## Reducer Actions
- `LINK_EPISODE` — creates/updates session with episodeId (returns state if missing)
- `CREATE_SESSION` — requires episodeId in session object

## Migration Notes
- Existing `content_episodes` rows get `series_id`, `episode_number`, `overlay_session_id`, `caption_track` columns added via ALTER TABLE (idempotent)
- Existing `overlay_sessions` table is created fresh (no prior data)
- `mapEpisode()` now returns `series_id`, `episode_number`, `overlay_session_id`
