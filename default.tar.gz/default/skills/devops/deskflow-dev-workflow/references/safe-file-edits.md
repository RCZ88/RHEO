# Safe File Edits in DeskFlow (no data loss, no illegal git)

## The two failure modes this guards against
1. **`write_file` truncation** — writing a file you only read with `offset`/`limit` pagination
   replaces the WHOLE file with just the slice you saw. A prior session truncated
   `DeadlinesCard.tsx` 812 -> ~20 lines this way.
2. **Illegal git self-recovery** — using `git checkout -- <path>` / `git restore` / `git reset --hard`
   to "undo" a bad edit. AGENTS.md 0.5 bans all of these. They also discard unrelated uncommitted
   work. The handoff session for this skill ran `git checkout -- src/components/dashboard/DeadlinesCard.tsx`
   three times (transcript lines 4256/4830/5092) — a contract violation.

## Decision rule
| Situation | Use |
|---|---|
| New file, or file fully read in one `read_file` call | `write_file` (safe) |
| Edit a file you only partially read | `patch` (find-and-replace) — surgical, never truncates |
| Edit a file you fully read but want to change ~1 region | `patch` (preferred) or full `write_file` with COMPLETE content |
| You broke a file with a bad `write_file` | `read_file` it fully, then `patch`/`write_file` with the COMPLETE intended content |
| You need to "undo" to last good version | Physical backup w/ explicit user permission ONLY (AGENTS.md 0.5). NEVER git. |

## Concrete recovery recipe (no git)
If a `write_file` truncated a large component (e.g. it now has no imports/functions):
1. `read_file` the file in FULL (no offset/limit).
2. Decide the minimal surgical fix and apply it with `patch`, OR rewrite the whole file with
   `write_file` passing the COMPLETE content (every import + function + JSX you intend to keep).
3. Verify: `npx tsc -p tsconfig.app.json --noEmit` (filter for the file you touched — should show 0
   errors) and/or `npm run build:renderer`.

## Build/verify after an edit (the gate)
- Renderer-only change: `npm run build:renderer` (vite, ~1m15s). Green = "built".
- Full pipeline (main/preload touched): `node scripts/build.mjs` (~5 min).
- Type-only check: `npx tsc -p tsconfig.app.json --noEmit` then `grep -c "error TS"`.
  NOTE: the app intentionally ships with 2 known error sites that are NOT yours:
  `src/components/FocusGroupVenn.tsx` (untracked prior-session WIP, has a syntax error at ~320) and
  `src/services/ai/aiAgentService.test.ts` (pre-existing, untouched). If your file is not in the
  error list, the rest is inherited noise — do not "fix" those.

## Worked example: Self page `<CanvasGraph />` crash
Symptom (user-pasted): `CanvasGraph (CanvasGraph.tsx:56:13) Cannot read properties of undefined
(reading 'length')`.
Root cause: `SelfOrchestrator.tsx` rendered `<CanvasGraph />` with NO props; line 56 does
`if (!nodes.length) return` where `nodes` was `undefined`.
Fix (no git): load real graph data (mirror `ContextGraphView.tsx` `loadGraphData` — `brainGetEntities`
+ `brainGetFacts`->edges + `learnGetNodes`), measure container w/h via `ResizeObserver`, pass
`nodes`/`links`/`width`/`height`/`onNodeHover`/`onNodeClick`/`hoveredNode`/`selectedNode`/
`selectionSet` to `CanvasGraph`. Add loading + empty states. `write_file` the full corrected file.
Verified: `tsc` 0 errors in the file; `build:renderer` green.
