# Workspace vs App-Shell Scoping (DeskFlow)

## The rule
`App.tsx` = app-wide shell (global sidebar, global header toolbar, `<Routes>` table). Anything
mounted at its root renders on **every** page. The **workspace** is the `/terminal` route rendered by
`TerminalPage.tsx` — a distinct, scoped surface. Workspace features MUST mount inside `TerminalPage`.

## How to move a feature from app-shell into the workspace (worked example: Selection Engine)

### 1. Strip it out of `App.tsx`
- Remove the provider wrapper (e.g. `<SelectionProvider>` + `<SelectionEngineActivator />`).
- Remove the floating/overlay components (`<SelectionOverlay />`, `<SelectionToolbar />`,
  `<SelectionResultPanel />`) and any global toggle button in the header.
- Delete imports that become unused (e.g. `MousePointer2`, the selection-engine import).
  ⚠️ Double-check each removed import is truly unused in App.tsx before deleting — e.g.
  `VoiceProvider` is still used by the `<VoiceProvider>` wrapper, so keep it.
- Verify: `search_files` for `SelectionProvider` in `src/App.tsx` → 0 hits.

### 2. Mount it inside `TerminalPage.tsx`
- Add import:
  `import { SelectionProvider, SelectionOverlay, SelectionToolbar, SelectionResultPanel, SelectionEngineActivator } from '../features/selection-engine';`
- Wrap the `<PageShell page="terminal" ...>` content in `<SelectionProvider>`. The PageShell opens at
  the component's main `return (` and closes at its `</PageShell>`; insert `<SelectionProvider>` right
  after the `<PageShell ...>` opening tag and `</SelectionProvider>` right before `</PageShell>`.
- Mount the overlays + activator INSIDE the provider (before `</PageShell>`):
  ```tsx
  {/* Selection Engine — scoped to the workspace */}
  <SelectionEngineActivator />
  <SelectionOverlay />
  <SelectionToolbar />
  <SelectionResultPanel />
  </SelectionProvider>
  ```
- Add the toggle button into the workspace terminal tab bar (not the app header). It only needs to
  dispatch the window event, not consume context:
  ```tsx
  <button
    onClick={() => window.dispatchEvent(new CustomEvent('selection-engine:toggle'))}
    title="Select screen element for AI context (Ctrl+Shift+S)"
    className="p-1.5 rounded-lg bg-zinc-800/50 hover:bg-zinc-700 text-zinc-400 hover:text-amber-300 transition"
  >
    <MousePointer2 className="w-4 h-4" />
  </button>
  ```

### 3. Verify scoping
- `search_files` `SelectionProvider|SelectionEngineActivator|selection-engine:toggle|MousePointer2`
  in `src/App.tsx` → expect 0; in `src/pages/TerminalPage.tsx` → expect 7+.
- Confirm no OTHER page mounts the same overlay (e.g. `ActivitySelectionOverlay` in `ExternalPage` is a
  DIFFERENT component — browser-activity selection — leave it alone).
- Build: `node scripts/build.mjs` → green. Relaunch the app fully (running process holds old
  main.cjs) and confirm the pointer/toolbar appears ONLY inside /terminal.

## Quick decision test
"Should this UI show on pages other than /terminal?"
- No → workspace feature → mount in `TerminalPage.tsx`.
- Yes (or it's a top-level route) → wire a lazy `<Route>` in `App.tsx`; keep the component self-contained.
