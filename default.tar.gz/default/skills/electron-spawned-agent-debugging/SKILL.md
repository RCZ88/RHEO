---
name: electron-spawned-agent-debugging
description: "Debug Electron apps where the AI agent runs in a PTY."
category: software-development
version: 1.0.0
author: Hermes Agent (session-derived)
license: MIT
platforms: [windows, macos, linux]
metadata:
  hermes:
    tags: [electron, debugging, ipc, agent, pty, subprocess, context-injection, mcp]
    related_skills: [systematic-debugging, test-driven-development]
---

# Electron + Spawned-Agent Debugging

## When to use
You are debugging or building a feature in an Electron app where an AI coding agent (opencode,
claude-code, codex, gemini) is launched **inside a terminal/PTY as a child process** of the app,
and that agent is supposed to READ host context (brain memories, reflections, state) and/or WRITE
back to the host (save memory, log reflections).

This class of bug is invisible to normal debugging: there are no stack traces — the wiring just
silently never connects.

## The Iron Law (extends systematic-debugging)
**A missing IPC channel is a root cause, not a thing to paper over.** Before writing any
`on<Event>(...)`, `ipcRenderer.invoke('<channel>', ...)`, or `bridge.<method>(...)` call, grep
BOTH ends of the wire:
- PRODUCER: does `ipcMain.handle('<channel>'`, `webContents.send('<event>'`, or
  `contextBridge.exposeInMainWorld` actually register it?
- CONSUMER: does the preload/renderer bridge actually expose that method/event?

If either end is missing, the call is a no-op. Implement the channel or fall back to one you
verified exists. Never invent an event name and wire to it (e.g. `onTerminalOutputIdle` that was
never registered) — it compiles, never fires, and wastes a turn.

## The renderer/main/agent boundary
- **Renderer** JS world: `window.deskflowAPI.*` (Electron `contextBridge`). ONLY reachable from
  the app's own UI code.
- **Main process**: holds the DB, IPC handlers, and any standalone HTTP/MCP servers.
- **Agent subprocess** (in a PTY): a separate process. It CANNOT call `window.deskflowAPI.*`.
  It CAN `curl http://127.0.0.1:<port>`, read files, and write files.

So: an in-terminal agent has **no** direct path to renderer-only bridges. For agent→host
write-back you MUST expose a localhost HTTP/MCP server in the MAIN process and have the agent
`curl` it. See `references/spawned-agent-host-callback.md` for the working pattern.

## Context injection at spawn (common missing-feature bug)
A spawned agent terminal starts "clean" unless you feed it context. If a feature is meant to give
the agent prior-session memory/reflections:
- Inject context at **spawn**, not only on the first user message.
- Watch for a declared-but-unconsumed parameter (`initContent` that is never written to the PTY)
  — it silently leaves sessions context-free.
- Agents with no ready-signal (opencode prints no session id, emits no `onAgentReady`) need an
  agent-aware settle before you inject prompt/context, or it lands mid-boot. A true "output idle"
  gate needs main-process PTY support (not usually wired) — a verified fixed delay is the robust
  fallback, not a guessed event.

## Verification checklist (claim "the agent can use/update infra" ONLY if all pass)
- [ ] grep main.ts for `ipcMain.handle('<channel>')` AND preload for the bridge — both exist
- [ ] the host HTTP/MCP server is actually `start`ed in main.ts (defined ≠ running)
- [ ] the agent knows the port + token (documented where it can read it)
- [ ] context-assembly reads EVERY source expected (brain, reflections, dictionary, state)

## See also
- `references/spawned-agent-host-callback.md` — working HTTP/MCP callback pattern + curl recipe
- `systematic-debugging` — the 4-phase root-cause method this builds on
