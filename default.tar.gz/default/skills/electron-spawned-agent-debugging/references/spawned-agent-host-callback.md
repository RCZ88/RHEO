# Spawned-Agent → Host Callback Pattern (condensed)

When an AI agent is spawned as a child process inside a terminal/PTY (e.g. opencode,
claude-code) and needs to READ host context and/or WRITE back to the host's brain/state:

## The boundary
- The agent runs in a shell subprocess. It has NO access to the renderer's
  `window.deskflowAPI.*` (Electron `contextBridge` exposes that only to the renderer's JS
  world). Any code in the agent that calls `deskflowAPI.agentSend`/`brain.foo` is unreachable.
- The agent DOES have normal OS capabilities: it can `curl http://127.0.0.1:<port>`, read files
  on disk, and write files on disk.

## Read path (agent → host state)
- Host assembles context in the main process (e.g. an `assemble-context` IPC handler that pulls
  brain memories, reflections, state.md) and injects it into the agent's PTY at spawn via
  `agentSend`. The agent receives it as shell input — no callback needed.
- Inject at SPAWN, not only on first message; otherwise the session starts context-free.

## Write path (agent → host, e.g. save a memory / reflection)
- Host runs a localhost HTTP/MCP server in the MAIN process (NOT the renderer).
- Server pattern (observed, working): `http.createServer` + JSON-RPC 2.0 over POST, bound to
  `127.0.0.1:<port>`, optional bearer token header (`x-deskflow-mcp-token`, env-gated).
- Tools exposed: read (`search_context`, `get_entity`, `get_active_facts`, `get_recent_signals`)
  and write (`log_episode` → canonical memory write; `add_memory` → `logEpisode`; `add_reflection`
  → append markdown to the reflect-log dir the agent-reflect skill reads).
- The agent calls it with plain `curl`:
  `curl -s -X POST http://127.0.0.1:54322 -H 'content-type: application/json' \
   -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"add_memory","arguments":{"content":"..."}}}'`
- Filesystem alternative: an in-terminal agent can also write reflections directly to disk
  (markdown into the reflect-logs dir), which the host re-reads at next context assembly — no
  HTTP server required for the write side if the host polls that dir.

## Verification checklist before claiming "the agent can use/update infra"
- [ ] grep main.ts for `ipcMain.handle('<channel>')` and preload for the bridge — both must exist
- [ ] confirm the host-side HTTP/MCP server is actually `start`ed in main.ts (not just defined)
- [ ] confirm the in-terminal agent knows the port + token (documented somewhere it can read)
- [ ] confirm context-assembly reads every source you expect (brain, reflections, dictionary)
