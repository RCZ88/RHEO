---
name: electron-window-chrome
description: "Build custom window title bars for Electron apps."
category: software-development
version: "2.1.0"
author: Hermes Agent (session-derived)
license: MIT
platforms: [windows, macos, linux]
metadata:
  hermes:
    tags: [electron, window, titlebar, chrome, ipc, preload, frameless, native-ui]
    related_skills: [electron-spawned-agent-debugging]
---

# Electron Window Chrome (Custom Title Bar)

## When to use
The user wants to replace the default OS title bar (minimize/maximize/close buttons + window caption) with a custom-designed one that matches the app's visual style. Common signals: "the top bar looks ugly", "custom title bar", "remove native frame", "design the window controls".

## The pattern

A frameless Electron window has no OS chrome at all — you must rebuild every piece the native title bar provided: drag-to-move, minimize/maximize/close buttons, maximize/restore state tracking, and dimming on focus loss.

### Step 1 — Hide the native title bar (BOTH properties required)

In `main.ts` (or wherever you create the `BrowserWindow`):

```ts
mainWindow = new BrowserWindow({
  // ...other options...
  frame: false,            // CRITICAL: removes ALL native frame (Windows)
  titleBarStyle: 'hidden', // Removes native caption bar (macOS/Linux)
  backgroundColor: '#0a0a0a',
})
```

**PITFALL — `titleBarStyle: 'hidden'` alone is NOT enough on Windows.** The `frame: false` property MUST also be set. Without it, the OS title bar persists even with `titleBarStyle: 'hidden'`, causing a double-titlebar or a gap between the native bar and your custom one. Verify by grepping `dist-electron/main.cjs` for both `frame: false` and `titleBarStyle: "hidden"`.

`titleBarStyle: 'hidden'` removes the native caption AND the drop shadow — you own the full top edge. On Windows this means the window has no resize handles either; add your own 4px invisible drag borders via CSS (`-webkit-app-region: none` on body, explicit edge regions) if you need them.

### Step 2 — IPC handlers in main process

Add these inside `createWindow()` so the renderer can control the window:

```ts
ipcMain.handle('window:minimize', () => { mainWindow?.minimize(); });
ipcMain.handle('window:maximize', () => {
  if (!mainWindow) return;
  mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize();
});
ipcMain.handle('window:close', () => { mainWindow?.close(); });
ipcMain.handle('window:isMaximized', () => mainWindow?.isMaximized() ?? false);
ipcMain.handle('window:isFocused', () => mainWindow?.isFocused() ?? false);
```

Also emit focus-change events so the renderer can dim the bar:

```ts
mainWindow.on('focus', () => mainWindow.webContents.send('window:focus-change', true));
mainWindow.on('blur', () => mainWindow.webContents.send('window:focus-change', false));
mainWindow.on('maximize', () => mainWindow.webContents.send('window:focus-change', mainWindow.isFocused()));
mainWindow.on('unmaximize', () => mainWindow.webContents.send('window:focus-change', mainWindow.isFocused()));
```

### Step 3 — Expose on the preload bridge

In `preload.ts` add to the `contextBridge.exposeInMainWorld` object:

```ts
windowMinimize: () => ipcRenderer.invoke('window:minimize'),
windowMaximize: () => ipcRenderer.invoke('window:maximize'),
windowClose: () => ipcRenderer.invoke('window:close'),
windowIsMaximized: () => ipcRenderer.invoke('window:isMaximized'),
windowIsFocused: () => ipcRenderer.invoke('window:isFocused'),
onWindowFocusChange: (callback: (focused: boolean) => void) => {
  const handler = (_e: any, data: any) => callback(data);
  ipcRenderer.on('window:focus-change', handler);
  return () => ipcRenderer.removeListener('window:focus-change', handler);
},
```

### Step 4 — Build the React component

The title bar MUST use CSS `-webkit-app-region` to separate draggable from interactive regions:

- `-webkit-app-region: drag` on the bar root (makes the whole bar draggable)
- `-webkit-app-region: no-drag` on every clickable element (buttons)

Without this, the buttons can't be clicked because the drag region eats pointer events.

See `references/titlebar-component.md` for a complete, copy-pasteable React component.

### Step 5 — Integrate into layout

The App root must become `flex-col`:
1. Title bar at top (`shrink-0`, fixed height)
2. Existing sidebar+content row below (`flex-1 min-h-0`)

The `min-h-0` on the wrapper is critical — without it, the flex child won't shrink and the title bar gets pushed off-screen by tall content.

### Step 6 — Verify the compiled output

After building, **always verify** that `dist-electron/main.cjs` contains both `frame: false` and `titleBarStyle: "hidden"`, and that the renderer bundle contains the TitleBar component:

```bash
node scripts/build.mjs
grep "frame: false\|titleBarStyle" dist-electron/main.cjs
grep "TitleBar\|data-titlebar-drag" dist/assets/index.*.js
```

If the old title bar still appears at runtime, the compiled binary wasn't rebuilt. The build tool caches output — always run the full `node scripts/build.mjs` and verify.

## Pitfalls

- **`frame: false` is REQUIRED in addition to `titleBarStyle: 'hidden'` on Windows:** Without `frame: false`, the OS title bar persists. This is the #1 reason custom title bars fail silently — the OS bar is still there behind/in-front of the custom one.
- **Forgetting `min-h-0` on the wrapper:** The flex child defaults to `min-height: auto`, so content overflows the viewport instead of scrolling. Always set `min-h-0` on the flex wrapper that sits below the fixed-height bar.
- **Drag region swallowing buttons:** If you forget `-webkit-app-region: no-drag` on buttons, clicks won't register — the drag region intercepts them.
- **Maximize state lag after drag-to-snap:** Windows drag-to-snap doesn't always fire the maximize event promptly. Poll `isMaximized()` every 500ms as a safety net.
- **Focus-dim flicker on maximize:** Firing `focus-change` from maximize/unmaximize handlers avoids a frame where the bar shows focused colors while the window is in a transition.
- **`titleBarStyle: 'hidden'` vs `'hiddenInset'`:** On macOS, `'hidden'` removes the traffic-light dots; `'hiddenInset'` keeps them but with inset margins. Use `'hiddenInset'` if you still want native traffic lights on macOS.
- **Stale compiled output after patching `main.ts`:** The build may cache old output. Always run `node scripts/build.mjs` and verify with `grep` that `frame: false` and `titleBarStyle: "hidden"` appear in `dist-electron/main.cjs`.
- **The TitleBar component must be imported in App.tsx:** If `import TitleBar from './components/TitleBar'` is missing, the build produces a `ReferenceError: TitleBar is not defined` at runtime. After adding a new component import, verify it appears in the compiled renderer bundle.
- **`write_file` truncation on large files:** App.tsx is ~3,700 lines. `write_file` replaces the ENTIRE file — a partial slice destroys all other code. Always use `patch` for surgical edits. If a file gets truncated, read it fully and rewrite completely, or restore via physical backup with explicit user permission.
- **`write_file` pagination data loss:** Never `write_file` a file you only read with `offset`/`limit`. The tool warns "was last read with offset/limit pagination" — heed it. Use `patch` instead.
- **TitleBar `borderBottom` must be `'none'`:** A visible separator line under the title bar is wrong. The `AppBackground` particles provide visual separation. Use `borderBottom: 'none'`.
- **Don't remove existing UI elements:** The title bar addition must not remove sidebar items, the theme toggle, the mobile connection button, or any other existing UI. The title bar is an ADDITION at the top — everything below stays exactly as it was.

## See also
- `references/titlebar-component.md` — complete React component with focus tracking, drag region, and hover states
- `references/titlebar-design-principles.md` — design philosophy: keep chrome minimal, preserve all existing UI elements
- `references/titlebar-layout-integration.md` — flex-col layout structure and AppBackground positioning rules
- `references/titlebar-troubleshooting.md` — common failures and verification recipes