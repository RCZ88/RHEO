# TitleBar React Component Reference

A complete, production-ready custom title bar for Electron apps using React. Uses `-webkit-app-region` CSS to separate draggable from interactive regions.

```tsx
import { useState, useEffect, useCallback } from 'react';
import { Minus, Square, Copy, X } from 'lucide-react';

/**
 * Custom title bar for frameless Electron windows.
 *
 * KEY CONCEPTS:
 * - The bar root uses `-webkit-app-region: drag` — the whole bar drags the window
 * - Buttons use `-webkit-app-region: no-drag` — they remain clickable
 * - Double-click the bar = maximize/restore
 * - Polls maximize state every 500ms as a safety net for drag-to-snap
 * - Listens to `window:focus-change` events for focus dimming
 */
export default function TitleBar() {
  const [isMaximized, setIsMaximized] = useState(false);
  const [isFocused, setIsFocused] = useState(true);

  const refreshState = useCallback(async () => {
    try {
      const max = await window.deskflowAPI?.windowIsMaximized();
      setIsMaximized(!!max);
    } catch { /* ignore */ }
    try {
      const foc = await window.deskflowAPI?.windowIsFocused();
      setIsFocused(!!foc);
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    // Initial poll
    refreshState();

    // Poll every 500ms for maximize state changes (drag-to-snap, double-click bar)
    const poll = setInterval(refreshState, 500);

    // Listen for focus changes from main
    const unsub = window.deskflowAPI?.onWindowFocusChange?.((focused: boolean) => {
      setIsFocused(focused);
      // Also refresh maximize state on focus change (covers drag-maximize case)
      refreshState();
    });

    // Double-click bar = maximize/restore
    const bar = document.querySelector('[data-titlebar-drag]');
    const onDblClick = () => window.deskflowAPI?.windowMaximize?.();
    bar?.addEventListener('dblclick', onDblClick);

    return () => {
      clearInterval(poll);
      unsub?.();
      bar?.removeEventListener('dblclick', onDblClick);
    };
  }, [refreshState]);

  const handleMinimize = () => window.deskflowAPI?.windowMinimize?.();
  const handleMaximize = () => window.deskflowAPI?.windowMaximize?.();
  const handleClose = () => window.deskflowAPI?.windowClose?.();

  return (
    <div
      className="shrink-0 h-9 flex items-center justify-between select-none"
      style={{
        background: isFocused
          ? 'linear-gradient(180deg, #1a1a1a 0%, #141414 100%)'
          : 'linear-gradient(180deg, #111111 0%, #0d0d0d 100%)',
        borderBottom: '1px solid rgba(255,255,255,0.04)',
        WebkitAppRegion: 'drag',
      }}
      data-titlebar-drag
    >
      {/* Left side — spacer (draggable) */}
      <div className="flex-1 h-full" />

      {/* Right side — window controls (not draggable) */}
      <div
        className="flex items-center h-full shrink-0"
        style={{ WebkitAppRegion: 'no-drag' }}
      >
        {/* Minimize */}
        <button
          onClick={handleMinimize}
          className="group h-full w-12 flex items-center justify-center transition-colors hover:bg-white/5"
          title="Minimize"
        >
          <Minus
            className="w-3.5 h-3.5 transition-colors"
            style={{ color: isFocused ? '#a1a1aa' : '#52525b' }}
            strokeWidth={1.5}
          />
        </button>

        {/* Maximize / Restore */}
        <button
          onClick={handleMaximize}
          className="group h-full w-12 flex items-center justify-center transition-colors hover:bg-white/5"
          title={isMaximized ? 'Restore' : 'Maximize'}
        >
          {isMaximized ? (
            // Restore icon (overlapping squares)
            <span className="relative" style={{ width: 14, height: 14 }}>
              <Square
                className="absolute transition-colors"
                style={{
                  top: 1,
                  left: 1,
                  width: 11,
                  height: 11,
                  color: isFocused ? '#a1a1aa' : '#52525b',
                }}
                strokeWidth={1.5}
                fill="none"
              />
              <Square
                className="absolute transition-colors"
                style={{
                  top: 4,
                  left: 4,
                  width: 11,
                  height: 11,
                  color: isFocused ? '#a1a1aa' : '#52525b',
                  fill: 'currentColor',
                  fillOpacity: isFocused ? 0.15 : 0.1,
                }}
                strokeWidth={1.5}
              />
            </span>
          ) : (
            // Maximize icon (single square)
            <Square
              className="w-3.5 h-3.5 transition-colors"
              style={{ color: isFocused ? '#a1a1aa' : '#52525b' }}
              strokeWidth={1.5}
              fill="none"
            />
          )}
        </button>

        {/* Close */}
        <button
          onClick={handleClose}
          className="group h-full w-12 flex items-center justify-center transition-colors hover:bg-red-500/10"
          title="Close"
        >
          <X
            className="w-3.5 h-3.5 transition-colors group-hover:text-red-400"
            style={{ color: isFocused ? '#a1a1aa' : '#52525b' }}
            strokeWidth={1.5}
          />
        </button>
      </div>
    </div>
  );
}
```

## Integration into App root

The App root must become `flex-col` with the title bar above the existing layout:

```tsx
function App() {
  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <TitleBar />
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Existing sidebar + content */}
      </div>
    </div>
  );
}
```

**Critical**: The `min-h-0` on the wrapper is REQUIRED — without it, flex children default to `min-height: auto` and the title bar gets pushed off-screen.

## Window control bridge methods

The component expects these methods on `window.deskflowAPI` (exposed via preload):

```ts
windowMinimize: () => ipcRenderer.invoke('window:minimize'),
windowMaximize: () => ipcRenderer.invoke('window:maximize'),
windowClose: () => ipcRenderer.invoke('window:close'),
windowIsMaximized: () => ipcRenderer.invoke('window:isMaximized'),
windowIsFocused: () => ipcRenderer.invoke('window:isFocused'),
onWindowFocusChange: (callback: (focused: boolean) => void) => {
  const handler = (_e: any, data: any) => callback(data);
  ipcRenderer.on('window:focus-change', handler);
  return () => ipcRenderer.removeListener('window:focus-change', handler);
},
```

## Design notes

- Height: `36px` (h-9) — matches native title bar on most OSes
- Colors: Dark zinc/neutral palette that adapts to `isFocused` state
- Button width: `48px` each (w-12) — comfortable click targets
- Button hover: subtle `bg-white/5` — respects dark theme
- Close button: turns red on hover (`group-hover:text-red-400`)
- Maximize icon: toggles between single square and overlapping squares (restore)
