# Title Bar Design Principles

## Keep chrome minimal — the user hates heavy customization

When replacing the native title bar:

1. Don't add borders, lines, or decorative elements unless explicitly requested.
2. Don't remove existing UI elements to make room for the new title bar.
3. Height should be compact — h-9 (36px) matches native title bars.
4. Colors should be dark zinc/neutral — matching the existing app palette.
5. Buttons should be subtle — no heavy backgrounds, just hover states. Close should turn red on hover (macOS convention).

## What the user said (session evidence)

- "WHY ARE THOSE X BUTTONS AND STUFF HAVING CUSTOMIZE???" — buttons shouldn't be heavily styled
- "WHY IS IT ON THE LEFT SIDE OF THE TOP OF THE APPLICATION???" — title bar must be at the TOP
- "WH DID YOU REMOVE THE MOBILE CONNECTION BUTTON AND THE THEME AND EVERYTHING FROM THE PREVIOUS SIDEBAR???" — never remove existing UI elements

## Integration rules

- Title bar goes at the TOP of the flex-col root, BEFORE AppBackground and Sidebar.
- The existing sidebar, content, and all features remain untouched.
- App root: flex-col h-screen overflow-hidden.
- TitleBar: shrink-0 h-9 at top, then flex-1 min-h-0 wrapper below.
- borderBottom: none — no decorative line.
