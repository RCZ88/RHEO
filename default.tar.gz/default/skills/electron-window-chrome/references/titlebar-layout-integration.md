# Title Bar Layout Integration

## The flex-col root structure

When adding a custom title bar to an existing app, the App root MUST become `flex-col`:

```tsx
<div className="flex flex-col h-screen overflow-hidden bg-[#121212] text-white">
  <TitleBar />
  <AppBackground />
  <Sidebar ... />
  <div className="flex-1 min-h-0 flex flex-col overflow-hidden">
    {/* content */}
  </div>
</div>
```

## Element order (top to bottom)

1. **`<TitleBar />`** — `shrink-0 h-9`, at the very top. NO `borderBottom`.
2. **`<AppBackground />`** — `fixed inset-0 pointer-events-none z-[0]` — sits BEHIND everything as a particle layer. Must NOT be a sibling of TitleBar without the flex-col wrapper.
3. **`<Sidebar />`** — positioned alongside the content area, NOT below the title bar.
4. **`<div className="flex-1 min-h-0 flex flex-col overflow-hidden">`** — the main content wrapper. Contains the top bar (if any) and the route content. `min-h-0` is critical.

## AppBackground positioning

`AppBackground` renders as `fixed inset-0` — it fills the entire viewport behind all content. It must NOT be placed as a direct sibling of the title bar in a way that creates a visible gap or overlap. The correct structure:

```tsx
<div className="flex flex-col h-screen overflow-hidden">
  <TitleBar />  {/* shrink-0, sits at top */}
  <AppBackground />  {/* fixed inset-0, behind everything */}
  <Sidebar />  {/* flex column, alongside content */}
  <div className="flex-1 min-h-0 flex flex-col overflow-hidden">
    {/* content with its own top bar if needed */}
  </div>
</div>
```

**PITFALL — AppBackground above the content wrapper:** If `AppBackground` is rendered as a sibling of the content wrapper (inside the `flex-1` div), it covers the content. It must be a sibling of the `flex-1` wrapper, NOT inside it.

## TitleBar borderBottom must be removed

The TitleBar component must have `borderBottom: 'none'` (or no borderBottom at all). A bottom border creates an unwanted separator line between the title bar and the content below. The `AppBackground` particles naturally provide visual separation.

## The existing top bar stays in the content area

If the app has a top bar (e.g., with tracking controls, period selectors, time display), it stays INSIDE the `flex-1` content wrapper. The TitleBar handles ONLY window controls (minimize/maximize/close). The two bars serve different purposes:
- **TitleBar** = OS window chrome (drag, minimize, maximize, close)
- **Content top bar** = app UI controls (tracking, time, navigation)

Do NOT merge these into one bar. Do NOT remove the content top bar's elements.

## Common layout mistakes

1. **TitleBar inside the `flex-1` wrapper:** The title bar ends up scrollable and gets lost in content. It must be a direct child of the `flex-col` root.
2. **Missing `min-h-0` on the content wrapper:** The flex child defaults to `min-height: auto`, pushing the title bar off-screen.
3. **`<title>` tag still showing the old text:** After `frame: false`, the `<title>` in `index.html` still shows "RHEO" in the browser tab — this is expected and correct (it's the tab title, not the window chrome).
4. **`<link rel="icon">` still in `index.html`:** The favicon still appears in the tab bar — this is correct.
