# Title Bar Troubleshooting Guide

## Symptom: Old native title bar still visible

**Cause:** `frame: false` is missing from the BrowserWindow config, or the compiled `dist-electron/main.cjs` wasn't rebuilt after the edit.

**Fix:**
1. Verify `src/main.ts` has BOTH `frame: false` and `titleBarStyle: 'hidden'`.
2. Run `node scripts/build.mjs` (full build — not just `vite build`).
3. Verify: `grep "frame: false" dist-electron/main.cjs` and `grep "titleBarStyle" dist-electron/main.cjs`.

## Symptom: `TitleBar is not defined` ReferenceError

**Cause:** `import TitleBar from './components/TitleBar'` is missing from `App.tsx`.

**Fix:** Add the import to `App.tsx`. Verify it appears in the compiled bundle: `grep "TitleBar" dist/assets/index.*.js`.

## Symptom: Title bar buttons not clickable

**Cause:** Missing `-webkit-app-region: no-drag` on the button container. The drag region on the bar root eats all pointer events.

**Fix:** Ensure the button container div has `style={{ WebkitAppRegion: 'no-drag' }}`.

## Symptom: Title bar at the left/overlapping sidebar

**Cause:** The `flex-col` wrapper is missing, or the TitleBar was placed inside the sidebar's flex row instead of as a sibling.

**Fix:** Ensure App root is `<div className="flex flex-col h-screen overflow-hidden">` with `<TitleBar />` as the first direct child, followed by `<AppBackground />`, `<Sidebar />`, and the content wrapper.

## Symptom: Title bar has a visible bottom border/line

**Cause:** `borderBottom: '1px solid rgba(255,255,255,0.04)'` is still in the TitleBar component's style.

**Fix:** Change to `borderBottom: 'none'`. Rebuild and verify: `grep "borderBottom.*none" dist/assets/index.*.js`.

## Sympton: Title bar content overlaps with the sidebar

**Cause:** The `flex-1 min-h-0` content wrapper is missing, causing the sidebar to not properly reserve space beside the content area.

**Fix:** Ensure the layout has: TitleBar (shrink-0) → AppBackground (fixed) → Sidebar + content-wrapper (flex-1 min-h-0).

## Symptom: Old compiled output still running

**Cause:** The running Electron process holds the old `main.cjs`. Build caching or stale `.build-lock` file.

**Fix:** Delete `.build-lock` if stale (check PID), then run `node scripts/build.mjs`. Fully restart the app — a running process does not pick up new compiled files.

## Symptom: Build fails after editing App.tsx

**Cause:** `write_file` truncated App.tsx (~3,700 lines) to a partial slice.

**Fix:** Do NOT use `write_file` on large files. Use `patch` for surgical edits. If already truncated, restore via `git checkout HEAD -- src/App.tsx` (only for recovery, per AGENTS.md §0.5 physical backup rule — or re-read the file fully and rewrite completely). Verify: `npx tsc -p tsconfig.app.json --noEmit`.

## Verification checklist (run after every title bar change)

```bash
# 1. Build
node scripts/build.mjs

# 2. Verify main process
grep "frame: false" dist-electron/main.cjs
grep "titleBarStyle" dist-electron/main.cjs

# 3. Verify preload bridge
grep "windowMinimize\|windowMaximize\|windowClose" dist-electron/preload.cjs

# 4. Verify renderer has TitleBar
grep "TitleBar\|data-titlebar-drag" dist/assets/index.*.js

# 5. Verify no borderBottom line
grep "borderBottom.*none" dist/assets/index.*.js
```

All checks should return matching strings. If any fail, the compiled output is stale — rebuild.
