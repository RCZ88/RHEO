---
id: frontend-component-sourcing
name: frontend-component-sourcing
description: "Get real UI components when the design MCPs are offline."
version: 1.1.0
category: design
author: hermes-agent
license: MIT
tags: [frontend, react, components, reactbits, magicui, shadcn, tailwind, vite, tokens, monochrome, no-mcp]
metadata:
  hermes:
    tags: [frontend, react, design, no-mcp]
    related_skills: [frontend-external-infra, frontend-design, taste-skill]
---

# Frontend Component Sourcing (no-MCP fallback)

## When to use this skill
- A UI/landing/component build task where the Skill Router's DESIGN path is active
  (frontend-external-infra was loaded) BUT the MCP servers it lists
  (`reactbits-dev-mcp-server`, `@magicuidesign/mcp`, `shadcn-ui-mcp`) are **not**
  connected to this runtime (their tool funcs are absent from the tool list).
- The project is **Vite + Electron** (or any non-Next.js app), so `next/font` does
  not apply.
- You need real, curated component source — NOT a hand-rolled generic look-alike.

## Hard rules
1. **NEVER invent a component from zero when a source exists.** `frontend-external-infra`
   states: "if a source isn't available, say so — do not invent a substitute that
   looks generic." When the MCP is absent, *fetch the real source from the public
   registry* (recipes below) and adapt. Do not fabricate.
2. **`next/font` is Next.js-only.** In Vite/Electron it will not compile. Substitute:
   - the existing Google Fonts `<link>` in `index.html` (Space Grotesk + JetBrains Mono
     are usually already linked), OR
   - self-host with `@fontsource/space-grotesk` + `@fontsource/jetbrains-mono`.
   Never write `next/font/google` in a Vite project.
3. **Monochrome / LAMINAR pass** on every fetched component:
   - hairline borders (`rgba(255,255,255,.08)`) instead of `box-shadow`;
   - white-only accents — no hue;
   - mono labels 11–12px, uppercase, +14% letter-spacing;
   - all colors read from a single `tokens.css` (`--bg-0`, `--text-hi`, `--hairline`,
     `--ease-out-expo`); bloom/glow capped at 8%.
4. **Gate before claiming done:** run the scoped color audit (see references) over the
   new component directory. Only pure white/black alpha values may appear.

## Sourcing recipes (verified working)
See `references/real-registries.md` for the exact, copy-paste commands
(shadcn CLI, magicui GitHub tarball, React Bits `@appletosolutions/reactbits`
tarball) and the audit grep. These are deterministic — they are the validated
method, not a list of dead ends.
See `references/deslop-revamp.md` for the concrete de-slop recipe (two-phase
foundation/restyle discipline, grep gate, loop-purge list, build gotchas).
See `references/verified-component-sources.md` for provenance of the actual
components fetched from the two registries during the 2026-08-31 sourcing pass
(shape caveats, fit assessment, fetch-hygiene note).

## Verification before reporting success
- `eslint` on the new dir: 0 errors.
- Isolated bundle: `npx esbuild entry.tsx --bundle --format=esm --loader:.css=empty
  --jsx=automatic --external:react --external:react-dom --external:framer-motion
  --external:lucide-react --outfile=out.js` → exit 0.
- Scoped color audit: empty of stray hues.

## Pitfalls
### `/tmp` and `AppData\Local\Temp` reject curl download bodies (verified in-session)
In some Hermes shell contexts `touch /tmp/f.txt` succeeds but `curl -o /tmp/f.tar.gz
<url>` writes 0 bytes — the directory is writable for `touch` but the download body
is blocked. Same for `AppData\Local\Temp`. **Workaround:** write scratch to the CWD
(repo root) or another verified-writable location, then move the tarball into place.
Always `ls -la <file>` and `head -c 4 <file> | xxd` (gzip magic `1f8b`) to confirm
the download landed before extracting. Do not assume `/tmp` is writable for downloads
just because `touch` works there.
### `AnimatedBeam` is a two-ref hero connector, NOT a standalone wave
The real Magic UI `AnimatedBeam` assumes a *hero layout* connecting two named DOM refs
(`fromRef`/`toRef`) and ships a hardcoded orange→purple gradient (`#ffaa40`→`#9c40ff`
— a hue violation out of the box). It is built to draw a curved stroke between two
named nodes, NOT to be a single decorative wave element. Do NOT drop it into a
single-wave area (e.g. an ActFlow ridgeline zone) without (a) stripping the
gradient to `currentColor`/white, (b) decoupling from the ref-pair layout into a
standalone SVG path, and (c) accepting it overlaps — not extends — whatever
crossfaded wave paths already exist. If you want a "beam" element, repurpose the
existing wave `d` paths rather than importing `AnimatedBeam`.
### 21st-dev MCP endpoint reachable but tools not invocable here
`@21st-dev/magic` may be configured in `opencode.json` with the endpoint alive
(GET returns `Method Not Allowed` = server up) yet no direct MCP tool is present in
this runtime's tool list. In that case the tarball recipes in `references/real-registries.md`
are the deterministic, validated path — fetch real source and adapt. Do not spin waiting
for an MCP tool call that won't resolve; the recipes were verified working.

## Revamping EXISTING AI-slop components (LAMINAR cleanup)
When the task is to fix an already-built but "sloppy" UI (gradient bars, spring
bounce, glassmorphism, emoji icons, raw hex in components) — not to fetch new
components — apply the same LAMINAR law as a *cleanup* pass. This is the inverse of
the fetch-and-adapt flow above and is the common "de-slop the app" request.

### Verify the real Source of Truth FIRST (pitfall)
- Do NOT assume `src/tokens.css` is the app SSoT. In this repo `tokens.css` is the
  **landing-page monochrome law** (white/black only, ~0 component usage) while the app
  actually runs on `src/index.css` Tailwind v4 `@theme`. A plan that says "make
  tokens.css the single source → index.css dies" would collapse the whole app to
  landing monochrome and break it.
- Find the real SSoT by grepping for token definitions and checking which file
  components actually import/use. Trust usage, not the plan doc.
- `data-page` theme maps are often DEAD (set in router but the `[data-page=...]`
  block in CSS keyed to obsolete route names). Re-key to live routes.

### Per-violation fix patterns (the de-slop checklist)
- Decorative chrome gradient bar (`bg-gradient-to-r from-X via-Y to-Z` as ornament)
  → delete the bar element entirely.
- Spring entrance (`transition={{ type:'spring', bounce:0.25 }}`) →
  `transition={{ duration: 0.2, ease: [0.16,1,0.3,1] }}`.
- `bg-zinc-900/95 border-zinc-700/50 shadow-2xl` (heavy chrome) →
  `bg-zinc-900/80 border border-white/10` (hairline).
- Raw hex inside a `.tsx`/`.tsx` component → replace with a token via `var(--token)`
  (e.g. `#ec4899`→`var(--accent-primary)`, `#f59e0b`→`var(--amber-400)`,
  `#f0a892`→`var(--clay-300)`). Put color values ONLY in the token file.
- Emoji as icons (🌙 ☀️) → lucide-react equivalent (Moon, Sun).
- `ShinyButton` / glow components → flat button (`bg-amber-500/15 border border-amber-500/30`).
- `backdrop-blur` glass on chrome/toasts → flat (`bg-zinc-900/95 border`).
- Multi-hue collision (amber header + emerald CTA) → commit to ONE signal hue per
  surface; reserve emerald/rose for success/error semantic states only.
- Functional exceptions that are NOT slop: categorical color arrays (per-group
  accents), one-shot celebration (confetti w/ reduced-motion guard), recording/
  voice indicators. Leave those.

### Safety: backup before any in-place refactor
- The user requires a **physical file backup** before large refactors. Take it
  FIRST. Snapshot `pre/` (HEAD versions via `git show HEAD:<file>` — read-only, NOT
  checkout) and `post/` (current edited versions) of every touched file into a
  timestamped dir under the user's backup location. This is the restore point.
- **NEVER use `git checkout`** to restore (explicit user rule). Restore by copying
  the `pre/` file back over the working file.

### Verification gate (proves the revamp compiles)
- `npm run build` must exit 0 across ALL steps (renderer + main). Watch for false
  failures: this project's `scripts/build.mjs` writes a stale `.build-lock` (PID of a
  prior run); if it reports "Build already in progress (PID N)" but no such PID is
  alive, `rm -f .build-lock && rm -rf dist-electron/main-temp` and re-run. An
  `EPERM` on `dist-electron/main-temp/cyber_assets` is the same stale-temp artifact,
  not a code error.
- Scoped grep gate (LAMINAR §13.2): `grep -rEoh "#[0-9a-fA-F]{3,8}|rgba?\([^)]*\)"
  src/` — every surviving hex/rgba must exist in the token file or be pure
  black/white. Re-run on the specific surfaces you touched to confirm 0 chrome slop.

## Overlay Studio integration (2026-09-01)
BlurFade and NumberTicker have been adapted into `src/features/overlay-studio/components/ui.tsx` for the RHEO app's Overlay Studio UI revamp. These are the verified LAMINAR-clean adaptations:
- `BlurFade` — `useInView` + directional offset + blur entrance. No hue, white opacity only.
- `NumberTicker` — `useMotionValue` + `useSpring` + `useTransform` from framer-motion. White `tabular-nums` mono output.

Other components (BentoGrid, AnimatedBeam, DecryptedText, ScrollVelocity) were fetched but assessed as unsuitable — see `references/real-registries.md` → "Verified fetch results (2026-09-01 session)".

## Relationship to other skills
- Complements (does NOT replace) `frontend-external-infra`, which documents the MCP
  path. Use THIS skill only when those MCP tools are unavailable.
- The project's own `agent/skills/frontend-external-infra/SKILL.md` is the canonical
  source for the MCP route; recommend the project maintainer add a "no-MCP fallback"
  subsection pointing here.