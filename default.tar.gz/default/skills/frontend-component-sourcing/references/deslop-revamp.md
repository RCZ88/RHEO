# De-slopping an existing app UI (LAMINAR cleanup recipe)

Companion to the "Revamping EXISTING AI-slop components" section in SKILL.md.
Condensed from a real deskflow/rheo App Tracker revamp session.

## The two-phase discipline (external-AI plan + user glm)
A clean de-slop splits into FOUNDATION then RESTYLE. Doing restyle first creates
churn that the foundation then invalidates.
1. FOUNDATION (do first, gates after each step): token collapse to the REAL SSoT,
   fonts trimmed to 3, per-page accent map re-keyed to live routes, loop purge,
   single categorical-color source, name sweep (defer mass-rename).
2. RESTYLE: only after foundation, touch page/component chrome.

User rule that fired: "do NOT restyle pages yet — foundation only." Honor it:
finish foundation, report deferred destructive items (delete old DESIGN.md,
collapse `--ws-*`/`--resume-*`/pink→white) for sign-off rather than force-running
them.

## Grep gate (LAMINAR §13.2 — run before claiming done)
```
grep -rEoh "#[0-9a-fA-F]{3,8}|rgba?\([^)]*\)" src/ | sort | uniq -c | sort -rn
```
Every surviving hex/rgba must exist in the token file OR be pure black/white.
For a scoped surface check:
```
grep -nE "gradient-to|via-emerald|spring|bounce:|shadow-2xl|backdrop-blur|🌙|☀️" <file>
```
Goal: 0 chrome-slop matches on the surfaces you touched.

## Count baselines (this repo, for context — re-measure on your repo)
- ~592 distinct hex + 885 distinct rgba before cleanup.
- `infinite` animation hits: 52 before loop-purge → 43 after (remaining are
  feature loops: AI canvas, life ProfileTab, warmth — DEFER, they are not chrome).
- Fonts loaded: 29 → trim to Inter / Space Grotesk / JetBrains Mono in index.html.

## Named decorative loops to purge (in src/index.css @theme inline / keyframes)
aurora, shiny-text, shine, border-beam, pulse-ring, df-edge-breath, df-mesh-shift,
scorePulse, sidebarShine, background-position-spin, lyceum-glow-breathe,
lyceum-shiny-text, lyceum-gradient, tapestry-breathe. Keep functional ones:
voice-bar, voiceSolidify (one-shot), recording/voice indicators, thinking dots.
After removing a `@keyframes`, strip its class reference from the 3 components that
used it (e.g. RingCanvas `df-edge-breath`, ambient-patterns `df-animate-mesh`,
neon-gradient-card `animate-background-position-spin`).

## Single signal hue per surface (constitution)
- amber → time-domain (Gap-Fill modal, AFK prompt)
- pink/clay (`--accent-primary` #ec4899, `--clay-*`) → Focus / brand
- cyan (`--ws-accent`) → workspace/IDE
- emerald → success/filled state ONLY; rose → destructive/error ONLY
- categorical data-viz → single source file (here src/lib/CategoryColors.ts)

## Build gotchas (verification gate)
Project build: `node scripts/build.mjs` (npm run build). It is multi-step
(renderer + main process). False failures to expect:
- "Build already in progress (PID N)" with no such PID alive → stale `.build-lock`.
  `rm -f .build-lock && rm -rf dist-electron/main-temp` then re-run.
- `EPERM ... dist-electron/main-temp/cyber_assets` → same stale-temp artifact
  (cyber_assets is a 173MB junk zip left in dist/), NOT a code error.
Real success marker: `✅ Build complete!` with exit 0 across all 4 steps.
