# Real component registries — no-MCP sourcing (verified)

Use these when the design MCP servers (`reactbits-dev-mcp-server`,
`@magicuidesign/mcp`, `shadcn-ui-mcp`) are NOT connected to the runtime.

## shadcn/ui — use the CLI (canonical, real source)
```
npx --yes shadcn@latest add button card tabs dialog --yes --cwd .
# emits @/components/ui/<name>.tsx (real registry source)
```
Then copy the ones you need into your feature dir and restyle to tokens so you
don't disturb other pages that import the shared `@/components/ui/*`.

## Magic UI — GitHub tarball (ui/magic-ui), not npm
`magicui` has no usable npm package. Pull the real source:
```
curl -fsSL "https://codeload.github.com/magicuidesign/magicui/tar.gz/refs/heads/main" -o magicui.tar.gz
tar -xzf magicui.tar.gz
# files at: magicui-main/apps/www/registry/magicui/<name>.tsx
# e.g. bento-grid.tsx, animated-beam.tsx, number-ticker.tsx, dot-pattern.tsx
```
Note: raw GitHub paths 404 (branch/path drift) — the codeload tarball works.

## React Bits — correct npm package is @appletosolutions/reactbits
The npm name `react-bits` is a DIFFERENT library (no DecryptedText/ScrollVelocity/
CountUp). The real one is `@appletosolutions/reactbits`:
```
curl -fsSL "https://codeload.github.com/appletosolutions/reactbits/tar.gz/refs/heads/main" -o rb.tar.gz
tar -xzf rb.tar.gz
# files at: reactbits-main/src/<Name>.tsx  (DecryptedText, ScrollVelocity, CountUp)
```
If `npm install @appletosolutions/reactbits` hits an ERESOLVE peer conflict, use the
tarball route above — same real source, no dependency resolution.

## Vite font substitution (next/font is Next-only)
- Prefer the existing Google Fonts `<link>` in index.html (Space Grotesk +
  JetBrains Mono are usually present).
- Or self-host: `npm i @fontsource/space-grotesk @fontsource/jetbrains-mono` and add
  `@fontsource/<x>/400.css` etc. imports. Never use `next/font/google` in Vite.

## Monochrome / LAMINAR restyle checklist (per component)
- Replace `box-shadow` with `border border-[var(--hairline)]` (rgba(255,255,255,.08)).
- Replace hue accents (e.g. AnimatedBeam orange→purple) with white→transparent.
- Labels: `text-[11px] uppercase tracking-[0.14em] font-mono`.
- Numbers/text: `text-[var(--text-hi)] tabular-nums`.
- Drive all color from tokens.css (`--bg-0`, `--text-hi`, `--hairline`,
  `--ease-out-expo`); cap glow at 8%.

## Scoped color audit (gate before "done")
```
grep -rEoh "#[0-9a-fA-F]{3,8}|rgba?\([^)]*\)" src/components/<dir>/ | sort | uniq -c
# Allowed: #ffffff, #fff, #050506, #f4f4f5, rgba(255,255,255,...), rgba(0,0,0,...)
# Anything else = violation. Fix in-scope (the new dir) before reporting clean.
```
If the full-repo grep is noisy (pre-existing palette elsewhere), scope it to the
new directory only — the monochrome law applies to the unit you built.

## Verification
```
npx eslint src/components/<dir> --ext .ts,.tsx   # 0 errors
npx esbuild probe.tsx --bundle --format=esm --loader:.css=empty --jsx=automatic \
  --external:react --external:react-dom --external:framer-motion --external:lucide-react \
  --outfile=out.js   # exit 0
```

## Verified fetch results (2026-08-31 session)
All five missing-slot components were fetched from the two public tarballs and
confirmed present (gzip header `1f8b`, non-empty). They live in a `_pending/`
area of the repo and have NOT been integrated — this section is a provenance
record, not an instruction.

### Magic UI tarball (`magicuidesign/magicui`, `refs/heads/main`)
- `bento-grid.tsx` — `BentoGrid`/`BentoCard`, `grid w-full auto-rows-[22rem] grid-cols-3`,
  dark-mode via `dark:`, heavy `box-shadow`/`dark:[box-shadow:...]` chrome.
  **Not LAMINAR** (hue-adjacent neutrals + heavy shadows). Do NOT import wholesale —
  the draft's own `Capabilities.tsx`/`Pricing.tsx` cards are a cleaner LAMINAR take.
  Only steal grid-column logic if needed.
- `animated-beam.tsx` — `AnimatedBeam` with `fromRef`/`toRef`, `pathColor`/`pathWidth`/
  `pathOpacity`/`curvature`, `duration`/`repeat`/`repeatDelay`, `gradientStartColor`
  (default `#ffaa40`) / `gradientStopColor` (default `#9c40ff`). **⚠️ Hue-violation
  built-in. Two-ref hero connector shape — NOT a standalone wave. See SKILL.md
  pitfalls before attempting to integrate.**
- `number-ticker.tsx` — `NumberTicker` with `value`/`startValue`/`direction`/
  `decimalPlaces`, `useMotionValue`+`useSpring`, `Intl.NumberFormat`, `tabular-nums`,
  `useInView` once. **Clean LAMINAR fit** (white/black only).

### React Bits tarball (`@appletosolutions/reactbits`, `refs/heads/main`)
- `DecryptedText.tsx` — `DecryptedText` with `text`/`speed` (ms, default 50)/
  `maxIterations`/`sequential`/`revealDirection`/`characters`/`animateOn` ('view'|'hover'),
  per-char scramble/reveal. **Clean fit for the text-scramble slot.**
- `ScrollVelocity.tsx` — `ScrollVelocity` with `texts[]`/`baseVelocity`/`velocityMapping`/
  `numCopies`/`damping`/`stiffness`, `useVelocity`+`useSpring`+`useAnimationFrame`,
  auto-wrapping marquee text. Close to a marquee but a text-scroller, not the SVG
  wave pattern the draft already has; likely redundant.

### Shape caveats (read before any integration)
1. **AnimatedBeam** — see SKILL.md pitfalls. Strip gradient to `currentColor`/white,
   decouple from ref-pair layout, accept overlap. Do not drop into ActFlow's
   crossfaded ridgeline zone; repurpose existing wave `d` paths instead.
2. **BentoGrid** — heavy `box-shadow` + neutral-700/400 text ≠ LAMINAR hairlines+white.
   Draft already has a better bento; only steal grid-column logic.
3. **ScrollVelocity** — text-scroller marquee (duplicate spans + baseVelocity). The
   draft's marquee (`Manifesto.tsx`/`TrustedBy.tsx`) uses CSS `translateX(-50%)` loop
   with `marquee-paused` — simpler, already pause-on-offscreen. `ScrollVelocity` is
   redundant here unless you specifically want scroll-coupled text speed.
4. **Spotlight card** and **magnetic button** — NOT present in either tarball. Need a
   separate source (e.g. `magicui-main/apps/www/registry/magicui/spotlight-card.tsx`)
   or a local build. See `agent/docs/landing_gap.md` work-order table for W6/W7.

### Fetch hygiene note
Scratch to the CWD (repo root) or another verified-writable location — in some
Hermes shell contexts `/tmp` and `AppData\Local\Temp` reject curl download bodies
even though `touch` succeeds there. Confirm with `ls -la` + `head -c 4 | xxd`
(gzip magic `1f8b`) before extracting.

## Verified fetch results (2026-09-01 session)
Components fetched and LAMINAR-adapted into the RHEO app (not left pending).

### Adapted (in `src/features/overlay-studio/components/ui.tsx`)
- `blur-fade.tsx` (Magic UI) → `BlurFade` entrance animation. Kept `useInView` +
  directional offset + blur; stripped the `filter` transition gating (unnecessary
  for our use). Pure LAMINAR — white opacity, no hue.
- `number-ticker.tsx` (Magic UI) → `NumberTicker`. Uses `useMotionValue` +
  `useSpring` + `useTransform` from framer-motion (NOT react-spring). White
  `tabular-nums` mono output. The Magic UI source had no hue to strip.

### Fetched but NOT integrated (assessed, rejected)
- `bento-grid.tsx` (Magic UI) — heavy `box-shadow` + neutral-700/400 text. Rejected:
  the app's existing cards (DashboardView ToolCard, ScenePlanView overlay cards) are
  already cleaner LAMINAR. Only the `grid-cols-3 auto-rows-[22rem]` logic is worth
  stealing if a bento layout is ever needed.
- `animated-beam.tsx` (Magic UI) — `fromRef`/`fromRef` two-ref connector with
  orange→purple gradient. Not used; not LAMINAR-able without full rewrite.
- `DecryptedText.tsx` (React Bits) — per-char scramble. Not needed for Overlay Studio.
- `ScrollVelocity.tsx` (React Bits) — text-scroller marquee. Redundant with existing
  CSS `translateX(-50%)` marquee pattern elsewhere in the app.