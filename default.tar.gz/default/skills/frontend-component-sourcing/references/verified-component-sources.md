# Verified component sources — real registry fetches (2026-08-31 session)

This file records the provenance of components actually fetched from public registries
during the 2026-08-31 landing-page sourcing pass. It exists so a future session can
distinguish "real source we pulled" from "component we built from scratch."

## Fetch command (deterministic — run again to re-fetch)
```
curl -fsSL "https://codeload.github.com/magicuidesign/magicui/tar.gz/refs/heads/main" -o magicui.tar.gz
curl -fsSL "https://codeload.github.com/appletosolutions/reactbits/tar.gz/refs/heads/main" -o rb.tar.gz
tar -xzf magicui.tar.gz
tar -xzf rb.tar.gz
```
Confirm landed: `ls -la magicui.tar.gz rb.tar.gz` + `head -c 4 magicui.tar.gz | xxd` (gzip magic `1f8b`).

## Magic UI — `magicui-main/apps/www/registry/magicui/<name>.tsx`
| File | Component | Fit |
|---|---|---|
| `bento-grid.tsx` | `BentoGrid`/`BentoCard` | Already have a cleaner LAMINAR version; steal grid-column logic only |
| `animated-beam.tsx` | `AnimatedBeam` | ⚠️ two-ref hero connector, hue-violation gradient; do NOT drop into ridgeline zone |
| `number-ticker.tsx` | `NumberTicker` | Clean LAMINAR fit — already implemented in draft |

## React Bits — `reactbits-main/src/<Name>.tsx`
| File | Component | Fit |
|---|---|---|
| `DecryptedText.tsx` | `DecryptedText` | Clean fit for text-scramble slot |
| `ScrollVelocity.tsx` | `ScrollVelocity` | Text-scroller; redundant vs draft's CSS marquee |

## Not found in either tarball
- **Spotlight card** (`spotlight-card.tsx`) — not in Magic UI main registry at fetch time; needs a separate source or local build.
- **Magnetic button** — not in either registry; needs a local `use-magnetic` hook build.

## Shape caveats (read before integrating any of these)
1. `AnimatedBeam` — strip gradient to `currentColor`/white; decouple from ref-pair; accept overlap. Repurpose existing wave paths instead.
2. `BentoGrid` — heavy `box-shadow` ≠ LAMINAR; draft already has cleaner cards.
3. `ScrollVelocity` — text-scroller, not the SVG wave the draft already has.

## Fetch hygiene note
Scratch to the CWD (repo root) or another verified-writable location — `/tmp` and
`AppData\Local\Temp` reject curl download bodies in some Hermes shell contexts
even though `touch` succeeds there. Confirm with `ls -la` + `head -c 4 | xxd`.
