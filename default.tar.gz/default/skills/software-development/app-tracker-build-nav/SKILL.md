---
name: app-tracker-build-nav
version: 5
author: hermes-coder101
license: mit
description: Build and add deep-nav to the App Tracker (RHEO) app.
metadata:
  hermes:
    tags: [react, vite, electron, typescript, navigation, build, deskflow]
    related_skills: [software-development/test-driven-development]
---

# App Tracker (RHEO) — Build & Navigation

React + TypeScript + Vite + Electron app. The global command palette (`src/components/GlobalSearchCommandPalette.tsx`) and deep-nav library (`src/lib/deepNav.ts`) are the standard way to jump to any page/sub-tab/section.

See `references/deep-nav-and-recap.md` and `references/aitoolstab-reaviz-timelines.md` for session-specific detail (navigation index, Daily Recap tab wiring, Venn integration, error transcripts, timeline chart migration).

## When to use this skill
- Running a build or typecheck for this project (and `tsc --noEmit` is misconfigured — see below).
- Adding a new navigable entry to the command palette, or making a palette item land on a specific sub-tab/section.
- Wiring any "navigate to X within the app" feature.

## VERIFIED BUILD RECIPE (do this, not `tsc` or bare `vite build`)
The authoritative check is the project's own build script (it runs renderer +
preload + services + main in one pass and is what AGENTS.md mandates):

    cd /c/Users/cleme/Documents/COMPUTAH_SAYENCE/App\ Tracker
    node scripts/build.mjs

- Run and check `✅ Build complete!`. All 4 steps (renderer, preload, services, main) must pass.
- The build uses a lockfile (`.build-lock`). If it says "Build already in progress", check `tasklist.exe` for orphaned node PIDs and `rm -f .build-lock` if dead.
- `npx tsc --noEmit` FAILS with TS6305 because the project uses composite/project-references — NOT a real type error.
- ESLint reports hundreds of pre-existing `no-explicit-any` / unused-var errors across the codebase. These are NOT blockers — the build is. Don't chase them unless the user asks.
- To type-check a SINGLE changed file cheaply: `npx esbuild < src/path/File.tsx --loader=tsx --jsx=automatic --format=esm > /dev/null` → `EXIT=0` means it parses. Use after every change.

## ASSEMBLECONTEXT IMPORT PITFALL (TerminalPage)
`src/pages/TerminalPage.tsx` historically imported `assembleContext` via a relative path that breaks the build. The sanctioned fix is the preload bridge:
```ts
const api = (window as any).deskflowAPI
if (api?.assembleContext) {
  const rendererContext = await api.assembleContext({ projectId: selectedProject, topic: sessionName, tokenBudget: 2000 })
}
```

## DEEP-NAV PATTERN (command palette → exact section)
App routing pages read their active sub-tab on mount from BOTH `localStorage` key and `location.state.tab`. `src/lib/deepNav.ts` centralizes this:

- `navigateTo({ route, tab, section, subpage }, navigate)` — sets the localStorage tab hint (key derived per route: `/settings`→`settings-activeTab`, `/ide`→`ide-activeTab`, `/finance`→`finance-activeTab`, `/reports`→`insights-activeTab`, else `${route}-activeTab`), persists `section` to sessionStorage, and calls `navigate(route, { state: { section, tab, subpage } })`.
- `scrollToSection(sectionId)` — `document.querySelector('[data-section="<id>"]')` then `scrollIntoView({block:'center'})`. Returns false if not found (retry with backoff).
- Pages that support deep nav read on mount: Settings/IDE/Finance/Insights read `location.state.tab`; Terminal reads `location.state.group`/`subpage`; Focus reads `location.state.tab` (added in-session); AI switches `canvasMode` from `location.state.tab` ('canvas'|'deck'|'compositions').

### To add a palette entry that lands on a specific section:
1. In `GlobalSearchCommandPalette.tsx` `ITEMS`, add `{ id, label, route, tab?, section?, keywords, group, icon }`. `section` must match a `data-section="..."` anchor in the target page.
2. In the target page, ensure the sub-tab container (or mode container) has `data-section="<id>")`. If the page switches tabs via `activeTab` state, add the anchor to the relevant `activeTab === 'x' && (<div data-section="x">…)` or to each inner card/section within the tab body. **For inner sections within a tab body (not just the tab container), tag each card/section individually** — e.g. `data-section="insights.recap.top-apps"`, `data-section="insights.recap.venn"`, etc. — so the palette can jump to a specific card, not just the tab's top-level container.
3. Wire the palette's `onNavigate` to call `navigateTo({route, tab, section}, navigate)` then retry `scrollToSection(section)` a few times (e.g. 8× @200ms) so it lands after the tab renders.
4. **The target page must ALSO consume the section hint and scroll.** Add a `useEffect` that calls `consumeSectionHint()` (from `../lib/deepNav`) and retries `scrollToSection(section)` with backoff (e.g. 5× @200ms). Without this step the tab switches but the page never scrolls to the card — the section is persisted to sessionStorage by `navigateTo` but only `consumeSectionHint()` / `scrollToSection()` actually reads it and moves the viewport.
5. Icon names must be valid `lucide-react` exports — `Audit` and `Alarm` do NOT exist; map them to `ShieldAlert` / `Bell` instead.

## IN-PAGE SUBPAGE TABS (the right way to make X a subpage of Y)
When the user says "make X a subpage of Y" in THIS app, they mean: remove X from the
sidebar and add it as a TAB inside Y's own in-page tab bar. Verified working pattern
(from a real refactor: External→Activity, Rankings→Insights, Database→Settings):

- **ActivityPage** (`src/pages/ActivityPage.tsx`): tab bar = `apps / websites /
  productivity / focus` (TABS array, `TabKey` type, `activeTab` state with `?tab=`
  URL read). Add `{ key:'external', label:'External', icon:Clock }` to TABS, accept
  `'external'` in the `?tab=` initializer, lazy-import `ExternalPage`
  (`const ExternalPage = lazy(() => import('./ExternalPage'))`), and render
  `<ExternalPage selectedPeriod={props.selectedPeriod} dateOffset={props.dateOffset}
  onDateOffsetChange={props.onDateOffsetChange} />` inside
  `{activeTab === 'external' && (...)}`. ActivityPage already receives
  `externalActivities`/`externalActivityTiers` props.
- **InsightsPage** (`src/pages/InsightsPage.tsx`): tab bar = `typical / weekly /
  activities` (plus `recap`). Add `'rankings'` to the `activeTab` union, the two
  `#tab=` hash validators, the tab-button map, and a
  `<Suspense><RankingsPage selectedPeriod={parentPeriod} dateOffset={dateOffset}
  onDateOffsetChange={onDateOffsetChange} tierAssignments={tierAssignments} /></Suspense>`
  block. `RankingsPage` is lazy-imported.
- **SettingsPage** (`src/pages/SettingsPage.tsx`): `tabs` array + `'category' |
  'colors' | ... | 'devices'` union. Add `{ id:'database', label:'Database' }` to
  `tabs`, add `'database'` to the union, and render
  `<Suspense><DatabasePage /></Suspense>` in `{activeTab === 'database' && (...)}`.
- KEEP each page's standalone `<Route path="/x">` in `App.tsx` so bookmarks/⌘K/legacy
  links still resolve. Embedding the page inside a parent does NOT remove its route.
- Do NOT build a sidebar dropdown for this — the user rejected that shape outright.

## CAPTURE & RECORDING PITFALLS (RHEO has TWO targets)

The RHEO project has **two distinct capture targets**. Clarifying which one the user means before you start saves a full redo:

| Target | What it is | Sections |
|---|---|---|
| **Electron desktop app** (`RHEO.exe`) | Time-tracking dashboard, runs in Electron | Dashboard, Activity, AI Assistant, Life, Documentation, Learn, Resume, IDE Projects, Finance, Insights, Settings, Guide |
| **Landing page** (`landing-mvp-draft/`) | Next.js marketing site, runs on `localhost:3000/3001` | hero, manifesto, act-record (300vh scrub), capabilities, understand, learn, atlas, flow, download |

When the user lists sections like "hero, manifesto, act-record, capabilities" → that's the **landing page**. When they say "the app" or "the application" without qualification → **ask which one**.

### Deliver visual files, NOT HTML dumps
When the user asks for screenshots/recordings, they want **actual visual media** (PNG, WebM) saved to disk — NOT raw HTML source dumped to the terminal. Do NOT `curl` the page and print the HTML. Use:
- `computer_use(action="capture")` for the Electron app (saves PNG automatically)
- Playwright `page.screenshot()` / `recordVideo` for scripted captures
- Reference the saved file paths in your response; don't paste page source

### Landing page capture recipe
The landing page is a Next.js app at `landing-mvp-draft/`:
```bash
cd landing-mvp-draft
npm run build          # outputs to .next/standalone/
node .next/standalone/server.js  # binds to port 3000 (or 3001 if taken)
```
Then drive it with Playwright (already installed there) or `browser_*` tools against `http://10.81.99.28:3001/` (or `localhost:3001`).

### Electron app capture recipe
The Electron app is already running as `RHEO.exe` (pid varies). Use `computer_use`:
```
computer_use(action="capture", mode="som", pid=<RHEO_PID>, window_id=<RHEO_WID>)
```
Find pid/window_id via `computer_use(action="list_windows")` → filter for `RHEO.exe`. The capture saves a PNG automatically and returns the path.

## CUSTOM TITLE BAR (Electron)
When the user wants to replace the native OS title bar with a custom one:

1. **main.ts**: Change `titleBarStyle: 'default'` → `'hidden'` in the `BrowserWindow` config.
2. **main.ts**: Add IPC handlers inside `createWindow()`:
   ```ts
   ipcMain.handle('window:minimize', () => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.minimize(); });
   ipcMain.handle('window:maximize', () => { if (mainWindow && !mainWindow.isDestroyed()) { if (mainWindow.isMaximized()) mainWindow.unmaximize(); else mainWindow.maximize(); } });
   ipcMain.handle('window:close', () => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.close(); });
   ipcMain.handle('window:isMaximized', () => mainWindow?.isMaximized() ?? false);
   ipcMain.handle('window:isFocused', () => mainWindow?.isFocused() ?? false);
   ```
3. **main.ts**: Emit `mainWindow.webContents.send('window:focus-change', true/false)` on `focus`/`blur`/`maximize`/`unmaximize` events.
4. **preload.ts**: Expose `windowMinimize`, `windowMaximize`, `windowClose`, `windowIsMaximized`, `windowIsFocused`, `onWindowFocusChange` via `ipcRenderer.invoke`/`ipcRenderer.on`.
5. **TitleBar component**: Use `-webkit-app-region: drag` on the bar container and `-webkit-app-region: no-drag` on buttons. Poll `windowIsMaximized()` every 500ms for state sync (covers drag-to-snap). Double-click bar = maximize/restore.

## SIDEBAR REDESIGN (shadcn-style hierarchical)
When redesigning the sidebar with collapsible sections:

1. **Structure**: Group nav items into sections (e.g., Overview, Tracking, Creation, Projects, Personal, System). Each section has an icon, label, and items array.
2. **Collapsible primitive**: Use `@base-ui/react/collapsible` (already in `src/components/ui/collapsible.tsx`). The `Collapsible`, `CollapsibleTrigger`, `CollapsibleContent` components are ready to use.
3. **Active state**: Auto-expand the section containing the current page via `useEffect` watching `location.pathname`.
4. **Visual hierarchy**: Use left-border accent (e.g., `border-l-amber-400`) on active items, color-coded icons per section, uppercase tracking-wider section labels.
5. **Collapsed mode**: 60px wide showing just icons; expanded 260px with labels + chevrons.
6. **cn() utility**: Create `src/lib/utils.ts` with `import { type ClassValue, clsx } from 'clsx'; import { twMerge } from 'tailwind-merge'; export function cn(...inputs: ClassValue[]) { return twMerge(clsx(inputs)); }`.
7. **Integration**: Replace old sidebar JSX in `App.tsx` with `<Sidebar collapsed={...} onToggle={...} pathname={...} />`. Keep the old `sidebarCollapsed` state and `toggleSidebar` callback — the new component consumes them as props.

## PITFALLS
- A palette item with only `route` (no `tab`/`section`) lands on the page ROOT, never the specific card — that was the original "navigation doesn't go to the subpage" bug. Always pass `tab` + `section`.
- Don't pass `section` for single-screen routes that have no anchor (e.g. /resume, /external); the scroll silently no-ops. Either add the anchor or omit `section`.
- The build error `Expected ")" but found "{"` from rollup can be transient/stale-transform; re-running `vite build` resolved it once with no file change. If esbuild-standalone parses the file fine, trust the re-run.
- Pre-existing WIP in the working tree (e.g. `SleepDetectionModal.tsx` half-finished v1.4 edit) can break the bundle. Confirm via `git status` whether a broken file is yours before "fixing" it.
- **Missing import after component replacement** — When replacing JSX with a new component (e.g., `<Sidebar />`), you MUST add the import statement (`import Sidebar from './components/Sidebar'`). The build will pass but runtime throws `ReferenceError: Sidebar is not defined`. After every JSX replacement, audit the imports block.
- **`write_file` on large TSX files is catastrophic** — `write_file` replaces the ENTIRE file. On a 3,695-line file like `App.tsx`, a single `write_file` call that accidentally gets an empty/stale string will nuke the whole file. Always use `patch` for surgical edits on large files, and never use `write_file` on files over ~100 lines unless you have the complete replacement content verified. If `write_file` corrupts a large file, restore from `git checkout HEAD -- <file>` immediately, then re-apply changes with `patch`.
- **Old JSX must be fully removed when integrating a new component** — When replacing old sidebar code with `<Sidebar />`, the old `motion.div` + `DndContext` + `AnimatePresence` blocks AND the old header/footer JSX must ALL be deleted. Leaving even one block creates duplicate renders or JSX structure errors. After the patch, grep the file for leftover fragments from the old component.
- **Verify `titleBarStyle` in compiled output** — After patching `titleBarStyle: 'default'` → `'hidden'` in `main.ts`, always grep `dist-electron/main.cjs` to confirm the compiled output reflects the change. The user reported still seeing the default title bar because the source was patched but the compiled output still had `titleBarStyle: "default"` — the build tool was caching stale output.
- **User prefers original logo component** — When redesigning the sidebar, preserve the existing `SidebarLogo` component (`src/components/SidebarLogo.tsx`) rather than creating a new icon/wordmark. The user rejected a new Layers icon + "RHEO" text in favor of the original gradient-text logo.
- **`onClick={onNavigate}` circular-JSON crash.** If a sidebar/page nav button is wired
  `onClick={onNavigate}` (handler passed directly), React injects the `MouseEvent` as
  arg → `navigate(event)` → Router `JSON.stringify`s a DOM node →
  `TypeError: Converting circular structure to JSON` on EVERY page. Fix: bind
  `onClick={() => onNavigate()}` (no arg) or `onClick={() => onNavigate(child.path)}`
  (explicit string). Audit all click handlers that feed `navigate()`/`resolveTo()`.
- **CSS parse-error cascade** — A single invalid CSS at-rule (e.g., `@property --dk-ring-p { ... }` with invalid syntax in `design-tokens.css`) can cascade and disable the ENTIRE stylesheet, making all CSS on the page appear broken. Always validate CSS syntax before concluding the design is broken. Chromium parses CSS strictly — one invalid declaration can kill the whole cascade. When debugging "CSS not loading", check the built CSS output for parse errors first.
- **design-tokens.css @property at-rule** — `@property` declarations require valid syntax (`syntax: '<color>'` etc.). An invalid `@property --dk-ring-p { ... }` in `design-tokens.css` caused a cascade failure. Remove or fix any invalid `@property` declarations.
- **Orphaned CSS in index.css** — Stray rules without selectors (e.g., `min-height: 100vh;` or `margin: 0 negative-prefix;`) break the entire stylesheet parser. Always verify `src/index.css` has no orphaned declarations.
- **verify_css_classes** — After any CSS rewrite, always run: `grep -rn "className=" src/components/ai/canvas/ | grep -oP 'className="[^"]+"' | sort -u` and cross-reference with the CSS selectors.
- **.dk-canvas-viewport.panning modifier** — `CanvasGrid.tsx` applies `className={`dk-canvas-viewport ${isPanning ? 'panning' : ''}`}` dynamically. The CSS must include `.dk-canvas-viewport.panning { cursor: grabbing; }` and `.dk-canvas-viewport.panning .dk-canvas-grid-layer { cursor: grabbing; }`. If the panning class is used in TSX but has no CSS rule, the cursor feedback is missing during pan. Always verify dynamic class modifiers have corresponding CSS rules.
- **CSS class names must match DOM exactly** — The canvas CSS must use the same class names as the TSX components emit. `canvas.css` targets `.dk-canvas-viewport` and `.dk-canvas-grid-layer`; `cards.css` targets `.dk-canvas-card` and related names. Cross-reference with `grep -rn "className=" src/components/ai/canvas/ | grep -oP 'className="[^"]+"' | sort -u`. The built CSS file names change hash on each build (e.g., `canvas.CO_u-jUC.css`), so always verify the built output, not source file names.
- **design-tokens.css import chain** — design-tokens.css is imported only by deck.css (via AiPageDeck.tsx). Canvas components import canvas.css and cards.css directly. If design-tokens.css is not imported by canvas.css, the CSS custom properties will not be defined when viewing the canvas standalone.
- **SQLite table referenced but never created** — When adding new DB tables (e.g. `context_entity_facts`), ensure the `CREATE TABLE` statement is in the schema initialization block (near `initializeStorage`). A handler that queries a table that doesn't exist will silently fail. Always verify the table exists in the DB schema before wiring a query to it.
- **isBrowserWithExtension fallback** — `isBrowserWithExtension()` returns `false` when `browsersWithExtension` is empty (extension not yet identified). This means the browser app CAN be tracked as a regular app before the extension identifies itself. Add `isKnownBrowser()` as a fallback that checks `BROWSER_PROCESS_NAMES` even when the extension hasn't identified itself yet.
- **AFK gap fill shows one gap at a time** — The AFK gap fill modal should show ALL gaps as a list, not one-by-one via a queue. Pass `multiGaps` to `GapFillModal` for the AFK case too (not just the Smart Fill modal).
- **Build lockfile** — The build script uses `.build-lock` (hyphen). If you see `Build already in progress (PID ...)` after confirming the PID is dead, remove `.build-lock` and rerun.
- **Avoid tunnel vision on broad task docs** — When the user references a long task document or says "fix everything I mentioned", scan the full document FIRST to identify ALL requested changes before editing one file. Fixing only the first item causes the user to repeat the remaining tasks.
- **Verify component imports after adding usages** — Adding a component usage without its import will compile/build fine but fail at runtime with `ReferenceError`. After editing JSX, read the imports block and confirm the new import exists.

## EDITING LARGE CRLF TSX FILES
`src/components/ai/AIToolsTab.tsx` is CRLF-only and large (~203 KB). When replacing
a specific JSX block inside it:

- **Do not** hand-roll Python byte-scan/replace scripts for exact JSX blocks.
  Even with `newline=''`, these tend to miss because the file's actual indentation,
  spacing, or config shape differs from the generated `old_string`.
- **Do** read the exact target region with `read_file`, then apply the `patch` tool
  using that exact text as `old_string`. This preserves CRLF and matches reliably.
- If an edit goes sideways, reset the file first: `git checkout -- src/components/ai/AIToolsTab.tsx`,
  then re-read the region and retry `patch`.

## REAVIZ INTEGRATION PITFALLS
- When replacing a chart in `AIToolsTab.tsx`, **verify the component import exists**
  in the file BEFORE assuming the usage is valid. A missing import causes a runtime
  `ReferenceError`, but the build can still pass because the JSX compiles.
- After adding `ReavizAreaTimeline` usage, read the imports region and confirm
  `import ReavizAreaTimeline from '../ui/ai/ReavizAreaTimeline'` is present.
  If not, add it before building/deploying.
- The file is CRLF-only (~203 KB). Use `patch` with exact text from `read_file`;
  do not hand-roll Python byte replacements.
- **Reaviz data-shape contract**: `AreaChart` expects nested chart data, not a flat
  `{key: Date; data: number}` shape. The wrapper must normalize series into
  `[{key: Date, data: {[seriesKey]: number}}]` or use `buildNestedChartData`/`buildShallowChartData`
  from `reaviz`. Passing flat objects causes runtime type crashes in reaviz internals.
- **`roundDecimals` / `toFixed` undefined crash**: reaviz internally calls
  `roundDecimals(value)` → `value.toFixed(5)`. If any datum resolves to `undefined`,
  this throws `TypeError: Cannot read properties of undefined (reading 'toFixed')`.
  Guard every numeric datum with `Number(value) || 0` before it reaches reaviz.
- **Prefer `StackedAreaChart`/`StackedAreaSeries` for multi-series timelines** when
  you want true stacking; plain `AreaChart` + multiple `AreaSeries` renders them
  overlapped unless the data is explicitly nested/stacked via reaviz builders.

## BUILD LOCK FILE
The build script uses `.build-lock` (with hyphen), not `.build.lock`. If you see
`Build already in progress (PID ...)` after confirming the PID is dead, remove
`.build-lock` and rerun the build.

## AVOIDING TUNNEL VISION
When the user references a broad task document like `AITOOLS31082026.md` or says
"fix everything I mentioned", scan the full document FIRST to understand all
requested changes before diving into one file. The user may have multiple
independent tasks (analytics charts, loading states, prompts, features) and
fixing only one will frustrate them.

## DAILY RECAP (InsightsPage — recap tab)
The InsightsPage (`src/pages/InsightsPage.tsx`) has a `recap` tab showing a
grouped breakdown for the selected period. Key wiring details for this session
(after the recap tab was built):

- The tab-bar button array must include `'recap'` explicitly:
  `(['typical', 'weekly', 'activities', 'recap', 'rankings'] as const).map(...)`.
  Omitting it makes the tab invisible even though `activeTab` supports it.
- The label ternary must map `recap` → `'Recap'`:
  `tab === 'recap' ? 'Recap' : 'Rankings'`.
- `activeTab` union type includes `'recap'` (line ~176).
- `data-section="insights.recap"` anchors the recap body for deep-nav.
- The recap body includes: grouped breakdowns (top apps, categories,
  productivity split, sleep overview, browser, external), a **Day-by-Day
  Summary** grid (one card per day joining `dailyStats` tracked time with
  `sleepTrends.daily` sleep/deficit), a **FocusGroupVenn** overlap diagram
  (Apps/Browser/External), and summary cards + sleep-trend chart.
- `Suspense`/`lazy` imports must be present whenever a page uses
  `lazy(() => import(...))` + `<Suspense>` — InsightsPage needs
  `import { lazy, Suspense } from 'react'` for its `RankingsPage` lazy
  boundary. Adding the lazy boundary without the imports causes
  `ReferenceError: Suspense is not defined` at runtime.
- **Per-section deep-nav requires THREE things**: (a) a `data-section="..."`
  tag on each card/section you want to jump to, (b) a palette item whose
  `section` matches that tag, and (c) the target page calling
  `consumeSectionHint()` + `scrollToSection(section)` in a mount `useEffect`.
  Without (c) the tab switches but the viewport never scrolls to the card.
  Example anchors: `data-section="insights.recap.top-apps"`,
  `data-section="insights.recap.venn"`, `data-section="insights.recap.days"`.
- **Day-by-Day Summary** grid (one card per day) joins `dailyStats` tracked
  time (keyed `day`) with `sleepTrends.daily` sleep/deficit (keyed `date`)
  via a `dailySummaries` useMemo. Each card shows date + weekday, tracked
  hours with a mini bar scaled to the busiest day, and sleep hours or
  deficit (red if deficit, emerald otherwise).
- `consumeSectionHint`/`scrollToSection` live in `src/lib/deepNav.ts`
  and are imported from `'../lib/deepNav'` in pages that support deep-nav
  section scrolling.

**NOTE:** The `Suspense is not defined` fix is a recurring pattern — every
time a lazy boundary is added to a page, double-check the react import
includes both `lazy` and `Suspense`. This was the cause of the runtime
error this session; the page's TSX transformed fine with esbuild-standalone
(because type errors in imports aren't caught by esbuild), but rollup
failed at bundle time / at runtime.