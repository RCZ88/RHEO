# AIToolsTab Reaviz Timeline Integration

Session notes for replacing the two AI timeline charts in `src/components/ai/AIToolsTab.tsx`
with `ReavizAreaTimeline`.

## Files involved
- `src/components/ai/AIToolsTab.tsx`
- `src/components/ui/ai/ReavizAreaTimeline.tsx`

## Timeline charts migrated
1. Model Usage Timeline — lines ~3573-3663
2. Tool Usage Timeline — lines ~3814-3917

## ReavizAreaTimeline props used
- `series`: `ReavizSeries[]`
- `xAxisTickFormatter`: `(value: Date, index: number) => string`
- `formatY`: `(v: number) => string`

## Dataset mapping
```tsx
series={datasets.map((ds) => ({
  key: ds.label,
  data: periodDays.map((d, i) => ({
    key: d,
    data: (ds.data[i] ?? 0),
  })),
  color: ds.borderColor || ds.backgroundColor || '#8b5cf6',
}))}
```

## X-axis formatter
```tsx
xAxisTickFormatter={(_, idx) =>
  format(periodDays[idx], numDays <= 7 ? 'EEE' : 'MMM dd')
}
```

## Y-axis formatter
```tsx
formatY={(v) => {
  if (aiChartMode === 'tokens') return formatTokens(v)
  if (aiChartMode === 'cost') return formatCurrency(v)
  if (aiChartMode === 'messages') return String(v)
  return String(v)
}}
```

## Pitfalls
- The file is CRLF-only (~203 KB). Use `patch` with exact text from `read_file`; do not hand-roll Python byte replacements.
- Other `<Bar>` charts remain in the file (lines 2044, 2117, 2791, 3059, 4038). Only the two timelines were migrated.
- **Always verify the component import exists in AIToolsTab.tsx** before assuming the usage is valid. A missing import causes runtime `ReferenceError`, but the build can still pass because JSX compiles.
