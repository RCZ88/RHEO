# Canvas CSS / DOM Class Name Mismatch — Session Notes (2026-09-01)

## Root cause of "canvas looks broken"

When the canvas CSS was rewritten with the "Deep Field" design, the class names in the CSS did NOT match the class names actually used in the TSX components. This caused all canvas styles to be silently ignored by the browser.

## Mismatched class names found

| CSS defined (wrong) | TSX actually uses (correct) | File |
|---|---|---|
| .dk-canvas | .dk-canvas-viewport | CanvasGrid.tsx |
| .dk-canvas-world | .dk-canvas-grid-layer | CanvasGrid.tsx |

## Verification method

Always cross-reference CSS class names against the actual DOM before declaring CSS "done":

```
grep -rn "className=" src/components/ai/canvas/ | grep -oP 'className="[^"]+"' | sort -u
grep -oP '^\s*\.[a-zA-Z][a-zA-Z0-9-]*\s*\{' src/components/ai/canvas/canvas.css | sort -u
```

## Fix approach

Update the CSS to use the exact class names the TSX components emit. Add aliases (comma-separated selectors) to maintain backward compatibility:

```css
.dk-canvas-viewport,
.dk-canvas {
  /* styles */
}
```

## design-tokens.css import chain

design-tokens.css is imported only by deck.css (via AiPageDeck.tsx). The canvas components import canvas.css and cards.css directly. If design-tokens.css is not imported by canvas.css, the CSS custom properties will not be defined when viewing the canvas standalone.

## CSS parse-error cascade (2026-09-01 root cause)

**Primary root cause of "CSS not loading on AI assistant page"**: An invalid `@property --dk-ring-p { ... }` at-rule in `src/components/ai/design-tokens.css` caused a CSS parse error that cascaded through the entire stylesheet in Chromium. This made ALL CSS on the AI assistant page appear broken, even though the class-name mismatch was a secondary issue.

### Cascade failure chain
1. `design-tokens.css` contains `@property --dk-ring-p { ... }` with invalid syntax
2. Chromium's CSS parser encounters the invalid at-rule and stops parsing the stylesheet
3. The entire stylesheet is discarded — no styles apply
4. Symptoms: all CSS appears broken, elements have no styling

### Validation recipe
When debugging "CSS not loading", always check the built CSS output for parse errors:
1. Build: `node scripts/build.mjs`
2. Inspect `dist/assets/index.XXXX.css` for invalid at-rules
3. Search for `@property`, `negative-prefix`, or any token that looks invalid
4. Remove or fix the offending declaration
5. Rebuild and restart the app

### Additional CSS issues found and fixed
- `src/index.css` lines 146-149: orphaned `min-height: 100vh;` duplicate and `margin: 0 negative-prefix;` without a selector — also broke the stylesheet parser
- `.df-glass` rule was missing from `src/index.css` — restored
- `.dk-canvas-viewport.panning` modifier missing from `canvas.css` — CanvasGrid.tsx applies `className={`dk-canvas-viewport ${isPanning ? 'panning' : ''}`}` dynamically but no CSS rule existed for `.dk-canvas-viewport.panning`. Added `.dk-canvas-viewport.panning { cursor: grabbing; }` and `.dk-canvas-viewport.panning .dk-canvas-grid-layer { cursor: grabbing; }` to canvas.css. Always verify dynamic class modifiers in TSX have corresponding CSS rules.
- Built CSS file hashes change on each build (e.g., `canvas.BkMlcul1.css` → `canvas.CO_u-jUC.css`). Always verify the built output, not hardcoded file names.