# Landing Page Capture Workflow

The `landing-mvp-draft/` is a Next.js marketing site. It has sections: hero, manifesto, act-record (300vh scrub), capabilities, understand, learn, atlas, flow, download.

## Build & Serve
```bash
cd landing-mvp-draft
npm run build
# outputs to .next/standalone/
node .next/standalone/server.js  # port 3000 (or 3001 if 3000 taken)
```

## Playwright Scripts (in `scripts/media/`)
Two scripts exist:
- `scripts/media/record.mjs` — records 1280×800 WebM clips of scripted interactions
- `scripts/media/shots.mjs` — per-section + full-page PNG captures at 1280×800 and 375×800

Run with:
```bash
node scripts/media/record.mjs
node scripts/media/shots.mjs
```

Output goes to `design/media/clips/` and `design/media/shots/`.

## Viewports
- Desktop: 1280×800
- Mobile: 375×800

## Sections (with selectors)
| Section | Selector | Notes |
|---|---|---|
| hero | `#hero` | Full-viewport hero |
| manifesto | `#manifesto` | Text section |
| act-record | `#act-record` | 300vh scrub — capture mid-scroll at p=0.5 |
| capabilities | `#capabilities` | |
| understand | `#understand` | |
| learn | `#learn` | |
| atlas | `#act-flow` | No `#atlas` id exists; act-flow is closest |
| flow | `#act-flow` | |
| download | `#download` | |

## Recordings (record.mjs)
1. `a-full-scroll-reverse` — top→bottom→top (proves reversibility)
2. `b-hero-burst-hold` — violent scroll burst → 2s hold (turbulence→recovery)
3. `c-act-record-scrub` — slow scroll through 300vh scrub
4. `d-atlas-rail` — slow scroll through rail (atlas substituted with act-flow)

## Notes
- Install Playwright first: `npm install --save-dev playwright@1.62.1`
- Server may bind to port 3001 if 3000 is occupied (check `netstat -ano | findstr :3000`)
- Access via `http://10.81.99.28:3001/` (or `localhost:3001`)
