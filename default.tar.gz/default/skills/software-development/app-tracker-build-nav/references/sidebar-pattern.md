# Sidebar Pattern — Hierarchical Collapsible Navigation

## Structure

```ts
interface SidebarItem {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  path: string;
  color?: string;
  badge?: string;
}

interface SidebarSection {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  items: SidebarItem[];
  defaultOpen?: boolean;
}
```

## Sections (RHEO app)

| Section | Items |
|---------|-------|
| Overview | Dashboard |
| Tracking | Activity (LIVE), Apps, Websites, Focus, Productivity |
| Creation | AI Assistant, Studio, Learn, Resume |
| Projects | IDE Projects, Finance, Insights |
| Personal | Life, Guide |
| System | Settings, Database, Privacy |

## Key Implementation Details

- **Collapsible**: Uses `@base-ui/react/collapsible` (already in `src/components/ui/collapsible.tsx`)
- **Active detection**: Compares `location.pathname` against item path (handles `?tab=` query strings)
- **Auto-expand**: `useEffect` watches `location.pathname` and opens the matching section
- **Visual**: Left-border accent (`border-l-amber-400`) on active items, color-coded icons
- **Collapsed**: 60px wide, icons only; expanded 260px with labels + chevrons
- **Footer**: Shows "Local SQLite · Zero Cloud" status text

## Files

- `src/components/Sidebar.tsx` — Main sidebar component
- `src/components/ui/collapsible.tsx` — Base UI collapsible wrapper
- `src/lib/utils.ts` — `cn()` utility (clsx + tailwind-merge)
- `src/components/SidebarLogo.tsx` — Original gradient-text logo (preserve, don't replace)

## User Preferences

- **Logo**: Use the existing `SidebarLogo` component (gradient-text "RHEO" wordmark with shine animation). Do NOT replace with a Layers icon + plain text.
- **Contrast**: Use proper dark background (`bg-[#0c0c0c]`) with `border-zinc-800/60` borders for clear visual separation. Avoid the old "glass" class that caused poor contrast.
- **Color-coded icons**: Each item should have its own color (e.g., Activity=pink, AI=purple, Finance=emerald) — not all the same muted gray.
