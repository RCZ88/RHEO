---
name: playwright-media-capture
description: "Capture screenshots + video of pages via Playwright."
version: 1.0.0
author: hermes-agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [playwright, media, screenshots, video, web, automation, lighthouse, og]
    related_skills: [dogfood]
---

# Playwright Media Capture

Capture production-ready screenshots and video of web pages using the **Playwright library** (not the browser tool). This is for asset generation — marketing stills, social clips, reduced-motion proofing, OG frames — not for interactive QA.

## When to use

- User asks for screenshots, recordings, captures, clips, "shots" of a page or site.
- Multi-viewport full-page + per-section captures.
- Scroll / interaction recordings for social proof (reversibility, turbulence, scrub).
- Reduced-motion pass (assert no animation).
- Lighthouse report.
- OG frame capture at 1200×630.
- The page is already deployed (local prod server, staging, or live URL).

## Prerequisites

- Playwright installed (`npm install --save-dev playwright` or already in devDependencies).
- The page must be **already served** — Playwright navigates to a URL. If it's a local build artifact, start the production server first (see `references/windows-serve.md` for the MSYS/Windows case where `bun` is absent and `&` backgrounding fails).
- On MSYS (git-bash), `bun` is often missing — use `node` directly for Next.js standalone: `node .next/standalone/server.js`.

## Workflow

### 1. Build & serve

Build the site if needed, then start the production server in the background.

- **Generic (Node):** `node <server-entry> > server.log 2>&1 &` then poll for readiness.
- **MSYS/Windows when `&` fails:** Use PowerShell `Start-Process` — see `references/windows-serve.md`.
- Verify with `curl -s -o /dev/null -w "%{http_code}" http://localhost:<port>/`.

### 2. Screenshots (full-page + per-section)

```javascript
const VIEWPORTS = [
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'mobile', width: 375, height: 800 },
];
```

For each viewport:
1. `browser.newContext({ viewport })` → `page.goto(URL, { waitUntil: 'networkidle' })`.
2. Full page: `page.screenshot({ path, fullPage: true })`.
3. Per-section: `page.evaluate` to `scrollIntoView` the target, then `page.screenshot({ path, clip: boundingBox })`. Get the box via `document.querySelector(sel).getBoundingClientRect()` returned from `page.evaluate`.
4. Mid-scrub capture (e.g. act-record at p=0.5): after `scrollIntoView`, scroll to `rect.top + rect.height * 0.5 - innerHeight * 0.4`, wait, then capture.

### 3. Recordings (recordVideo)

Pass `recordVideo: { dir, size: viewport }` to `browser.newContext`. The video records until `context.close()`. After closing, `await page.video().path()` returns the temp file path — **copy it** to a stable name immediately (the temp file is deleted when the process exits).

Script patterns:
- **Reversibility:** scroll top→bottom→top in N steps with `waitForTimeout` between.
- **Burst + hold:** several fast scrolls (`window.scrollTo` to random offsets, ~120ms apart) then a 2s hold.
- **Slow scrub:** many small scroll increments (e.g. 30 steps over 5-6s) through a tall section.

### 4. Reduced-motion pass

Create a context with `reducedMotion: 'reduce'` (Playwright 1.44+):
```javascript
browser.newContext({ viewport, reducedMotion: 'reduce' })
```
Capture per-section stills. Assert no ticking clock: take two footer screenshots 2s apart and compare pixel-identical (use `page.screenshot` → buffer compare, or note "asserted manually" in manifest). Scrub sections should render static panels.

### 5. Lighthouse

Use `playwright-lighthouse` or run the Lighthouse CLI against the served URL. Gate ≥90. Save the HTML/JSON report alongside the media.

### 6. OG frame

Capture at 1200×630 clip centered on the hero, or use `page.screenshot({ clip: { x, y, width: 1200, height: 630 } })`.

### 7. Manifest

Write `design/media/MANIFEST.md` indexing every file with viewport/dimensions/description + the Lighthouse score.

## Windows / MSYS pitfalls

- **`&` backgrounding fails** in non-tty bash — prints `bash: no job control this shell` and the process dies when the tool call ends.
- **`bun` missing** — use `node` for Next.js standalone output.
- **`npm run dev` fails with `'tee' is not recognized`** in PowerShell. The repo's dev script uses bash `tee` for log piping. Fix: provide a `start-dev.ps1` wrapper using `Tee-Object`, or run `npx next dev -p <port>` directly. See `templates/start-dev.ps1` for a reusable version that also kills the occupied port before starting.
- **Env vars in PowerShell** — `$env:PORT='3001'; Start-Process node -ArgumentList '.next\standalone\server.js' -RedirectStandardOutput 'server.log' -RedirectStandardError 'server.err.log'`.
- **`localhost` may not resolve** to the server's bound interface — try the LAN IP (e.g. `10.81.99.28`) or `127.0.0.1` directly if `localhost` returns 000.
- See `references/windows-serve.md` for the full pattern.

## Playwright install pitfalls

- **Wrong `node_modules`**: if Playwright tests are inside a subdirectory (e.g. `landing/e2e/`), the `@playwright/test` package must be installed in that subdirectory's `node_modules`, not the parent repo's. Run `cd <subdir> && npm install -D @playwright/test` then `npx playwright install chromium`.
- **Missing `playwright.config.ts`**: Playwright will fail with `Project(s) "chromium" not found` if no config defines projects. Add a minimal config before running `--project=chromium`.
- **Heredoc pitfalls on Windows**: `terminal cat > path << 'EOF'` will fail with "No such file or directory" if the parent directory doesn't exist. Use `write_file` instead.

## Tips

- Wait for `networkidle` + a 2s settle before capturing (Framer Motion / Lenis need time to finish entry animations).
- Sections may be absent from the page (e.g. "atlas" not built yet) — `document.querySelector` check before capturing; note skips in the manifest.
- `fullPage: true` captures the full scroll height; per-section uses `clip` to the bounding box.
- The hash-named temp video files (`page@<hash>.webm`) are deleted on process exit — copy to stable names right after `context.close()`.

## Output structure

```
design/media/
├── clips/               # webm recordings
│   ├── a-full-scroll-reverse.webm
│   ├── b-hero-burst-hold.webm
│   ├── c-act-record-scrub.webm
│   └── d-atlas-rail.webm
├── shots/               # png screenshots
│   ├── full-desktop.png
│   ├── hero-desktop.png
│   ├── ...
│   └── _index.json
├── og-hero-frame.png
├── MANIFEST.md
└── lighthouse/
    └── report.html
```
