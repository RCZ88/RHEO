# Windows / MSYS Server-Startup Pattern

The single most failure-prone step of browser media capture on this Windows + MSYS (git-bash) box is **starting the production server**. Three distinct breakers hit in sequence:

## The problem

1. **`&` backgrounding does NOT work in non-tty bash.**  
   `node server.js > log 2>&1 &` prints `bash: no job control this shell` and the process dies when the tool call returns. You cannot use the POSIX backgrounding trick.

2. **`bun` is missing.**  
   The project's `package.json` claims `bun .next/standalone/server.js`, but `bun` is not installed (and `which bun` fails). Use `node` directly.

3. **`localhost` may not resolve to the bound interface.**  
   After a successful start, `curl http://localhost:3000/` sometimes returns `000` (connection failed). The server is listening on the LAN IP (e.g. `10.81.99.28`) and/or `127.0.0.1`. Check with `netstat -ano | findstr :<port>` and hit the IP directly.

## The working recipe (PowerShell Start-Process)

```powershell
powershell -Command "Set-Location 'C:\path\to\project'; $env:PORT='3001'; Start-Process -FilePath 'node' -ArgumentList '.next\standalone\server.js' -RedirectStandardOutput 'server.log' -RedirectStandardError 'server.err.log' -PassThru | Select-Object Id"
```

- Set `$env:PORT` **inside** the same PowerShell invocation (prefix before `Start-Process`).
- `Start-Process` returns immediately with the PID; the process keeps running after the tool call ends.
- Stdout/stderr go to `server.log` / `server.err.log` — read them with `read_file` / `cat` (NOT via `process(poll)` — there is no Hermes process session).

Then verify:

```bash
netstat -ano | findstr :3001
curl -s -o /dev/null -w "%{http_code}" http://10.81.99.28:3001/
```

## Cleaning up / changing port

If the port is already in use (EADDRINUSE), find and kill the holder:

```bash
netstat -ano | findstr :3000     # get PID
taskkill //F //PID <pid>          # note: PowerShell requires //F, not -F
```

Or just pick a fresh port via `$env:PORT`.

## Diagnostic notes

- If `curl localhost` returns 000 but `netstat` shows LISTENING, the bound interface is the LAN IP, not loopback. Try the IP.
- If `server.err.log` contains `EADDRINUSE`, the port is held — pick another.
- If the server exits immediately, `server.log` will say why (missing module, syntax error, port conflict).
