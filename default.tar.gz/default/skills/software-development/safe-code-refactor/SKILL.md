---
name: safe-code-refactor
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [refactor, backup, design-system, tokens, restyle, safety]
    related_skills: [test-driven-development, plan, simplify-code]
description: Before big refactors, backup first and verify the real SSoT.
---

# Safe Code Refactor

## When to Use
- A multi-file refactor, design-token consolidation, or page restyle in a repo
  you don't fully own.
- Executing another agent's plan that says "collapse tokens", "delete dead
  docs", "wire up the dead X system", or "single source of truth".
- Any in-place edit touching >3 files, or any edit where a wrong assumption
  could gut a feature.

Use when about to perform a large in-place refactor, a design-system / token
consolidation, or a multi-file restyle in a codebase you don't fully own — and
especially when executing another agent's plan that says "collapse tokens",
"delete dead docs", or "rewire a system". This skill prevents irreversible
damage and prevents blindly executing a plan that conflicts with reality or the
user's earlier decisions.

## Hard rules (non-negotiable)

1. **Never run `git checkout`, `git reset --hard`, or `git clean`** in the
   user's repos. This is a standing user constraint (stated explicitly and
   reinforced mid-task). Restore points are made non-destructively (see below).
   Read-only git (`git show HEAD:<path>`, `git diff --stat`, `git ls-files`)
   is fine and encouraged.
2. **Make a physical restore point BEFORE any large in-place edit**, even if
   the change "looks safe". The user explicitly expects this. A refactor
   without a backup is not acceptable.

## Workflow

### Step 0 — Restore point (do this first)
- **Large/small repos:** full tar excluding `node_modules`, `dist`, `build`,
  `.git`, and other heavy/ignorable dirs:
  `tar --exclude="repo/node_modules" --exclude="repo/dist" -czf "repo.backup-<date>.tar.gz" repo/`
- **Huge repos (tar times out — ~200k files):** snapshot only the files you
  intend to touch. For each path `f`: copy current → `backup/post/$f`; copy
  `git show HEAD:$f` → `backup/pre/$f`. See `references/backup-snapshot.md` and
  `scripts/snapshot.sh`.
- Confirm the backup dir exists and the pre/post copies are non-empty before
  proceeding.

### Step 1 — Verify the assumed "single source of truth"
A file with a comment like "single source of truth" may NOT be the SSoT for the
surface you're editing.
- Grep for actual usage of the supposed SSoT tokens/classes across `src/` before
  collapsing anything. Real trap seen: a repo's `tokens.css` was the
  *landing-page* monochrome law (0 component usage), while the real app tokens
  lived in `index.css` `@theme`. Collapsing to the wrong file would gut the app.
- If the plan says "X becomes the SSoT, Y dies", confirm Y is actually dead
  (grep usage). Don't execute "or die" on a file other features still import.

### Step 2 — Confirm systems the plan says to "wire up" are actually dead
Grep before assuming. A "dead" per-page theme system, accent map, or router hook
may already be partially/fully wired (audit docs go stale fast). Re-key / extend
what exists rather than re-adding a parallel system.

### Step 3 — Sequence: foundation BEFORE restyle
Execute the foundation slice first (token collapse, loop purge, name sweep, wire
dead systems, write the constitution). Do NOT restyle individual pages until the
foundation is in place and verified. Foundation changes are low-risk-wide;
restyle is high-risk-narrow and should ride on a stable base.

### Step 4 — Grep-gate verification (after edits)
Run the slop/color gate and confirm no NEW violations:
`grep -rEoh "#[0-9a-fA-F]{3,8}|rgba?\([^)]*\)" src/ | sort | uniq -c | sort -rn`
Every surviving hex/rgba must exist in the SSoT tokens OR be pure black/white.
Report remaining violations as a list; fix them; don't claim success with raw
hex still in component files.

## Pitfalls

- **Don't blindly execute a cross-agent plan.** Reconcile it with the user's
  prior explicit decisions. If a plan step would undo an earlier pick (e.g.
  "collapse the pink brand to white" after the user chose pink for Focus),
  **flag and defer** that step for sign-off instead of running it.
- **Don't mass-rename / mass-delete** (product-name sweeps, doc deletions)
  without reporting counts first and getting the go-ahead. Report, defer.
- **`patch` tool fuzzy-match is whitespace-sensitive on JSX.** Multi-line
  old_strings that include indentation often fail; prefer single-line,
  uniquely-anchored edits. Verify each patch landed (re-read or `git diff`).
- **Diff stats can mislead.** A 300-line diff on a file may include large
  pre-existing uncommitted changes from before your session. Inspect the actual
  lines you touched (`git diff -- <file>` + targeted greps) rather than trusting
  the stat. Don't claim "I restyled X" if only a few lines were yours.
- **Scope discipline:** when both app-source and landing/website work are in
  scope, the user may want only the app-source edits. Confirm before spreading
  effort to website/landing surfaces.

## Support files
- `references/backup-snapshot.md` — exact restore-point commands (targeted + full).
- `references/design-grep-gate.md` — the color/hex census command + how to read it.
- `scripts/snapshot.sh` — non-destructive restore-point generator (targeted or full).
