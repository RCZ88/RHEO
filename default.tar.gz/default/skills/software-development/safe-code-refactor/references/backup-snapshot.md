# Restore-point recipes (non-destructive)

The user requires a physical backup BEFORE any large in-place edit. Never use
`git checkout` / `git reset --hard` / `git clean` to make or restore them —
those are banned in this user's repos. Restore points live outside the repo
(e.g. `C:/Users/cleme/AppData/Local/hermes/backups/`).

## Full repo (small/medium repos)
Exclude heavy/ignorable dirs so the archive is fast and small:
```
tar --exclude="repo/node_modules" --exclude="repo/dist" \
    --exclude="repo/build" --exclude="repo/.git" \
    -czf "repo.backup-<YYYYMMDD>.tar.gz" repo/
```

## Huge repo (tar times out — ~200k files)
Snapshot only the files you will touch. For each path `f`:
- current  -> `backup/post/$f`   (the edited version you may need to revert to)
- `git show HEAD:$f` -> `backup/pre/$f`   (the pristine version to restore)
```
mkdir -p backup/pre backup/post
for f in src/a.tsx src/b.css ; do
  mkdir -p "backup/pre/$(dirname "$f")" "backup/post/$(dirname "$f")"
  git show "HEAD:$f" > "backup/pre/$f" 2>/dev/null   # skip if untracked
  cp "$f" "backup/post/$f"
done
```
Restore a single file (no git): `cp backup/pre/<path> <repo>/<path>`.

## Verify before proceeding
- backup dir exists
- pre/ and post/ copies are non-empty
- if a file is untracked (no HEAD version), keep only the post/ copy
