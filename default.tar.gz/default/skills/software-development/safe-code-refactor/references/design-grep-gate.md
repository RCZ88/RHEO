# Design / slop grep-gate

Run after any design-token or restyle edit to prove no NEW raw colors were
introduced into component source.

```
grep -rEoh "#[0-9a-fA-F]{3,8}|rgba?\([^)]*\)" src/ | sort | uniq -c | sort -rn
```

## How to read it
- Every surviving hex/rgba MUST be either:
  - defined as a token in the real SSoT (e.g. `src/index.css` `@theme`), or
  - pure black/white expressed as `rgba(255,255,255,<a>)` / `rgba(0,0,0,<a>)`.
- Anything else is a violation. List the offenders (file:line via a second
  grep) and fix them — don't claim success with raw hex in `.tsx`/`.tsx`.

## Counts from the RHEO/App-Tracker session (for context, not targets)
- 592 distinct hex + 885 distinct rgba across `src/` before cleanup.
- 254 one-off hex. ~52 infinite decorative animation loops (battery-relevant:
  the app runs all day).
- After purging named CSS loops (aurora, mesh, shine, border-beam, edge-breath,
  scorePulse, sidebarShine, background-position-spin): ~9 removed, 43 remained
  (mostly feature-level loops like AI canvas / life ProfileTab — defer those
  from a "foundation only" slice).

## Token-verification gotcha
A file labelled "single source of truth" may not be the SSoT for the surface
you edit. In RHEO, `src/tokens.css` was the *landing-page* monochrome law
(0 component usage); the real app tokens were in `src/index.css` `@theme`.
Grep usage before collapsing "or die".
