---
name: safe-codebase-edits
description: Read repo contract before editing; nest nav, never reroute.
version: 1
author: hermes-agent
license: mit
hermes:
  tags: [refactor, navigation, routing, contracts, safety, react-router]
  related_skills: [simplify-code, systematic-debugging, test-driven-development]
---

# Safe Codebase Edits

## When to Use
Load this before editing any repo that ships with an operating contract
(AGENTS.md / CLAUDE.md / .hermes.md / opencode.json / .cursorrules), or whenever
the task is to reorganize, restructure, or clean up navigation, routing, or menus
("make X a sub-page of Y", "move X under Y", "clear up the sidebar").

Mandatory pre-flight for any edit task in a repo that ships with an operating
contract, and for any refactor that touches shared navigation/routing/menus.
The #1 way to waste the user's trust is to (a) start editing before reading the
repo's own rules, or (b) reshuffle a menu by moving/renaming routes and silently
breaking deep links, bookmarks, and command-palette entries.

## When to load this
- The task says "reorganize", "restructure", "move X under Y", "clean up nav", or
  any change to how pages/routes/menus are wired.
- The repo root contains AGENTS.md, CLAUDE.md, .hermes.md, opencode.json,
  .cursorrules, or a documented "startup ritual" / "operating contract".
- The user has ever said "read the instructions first" or "don't break stuff".

## Steps

### 1. Read the project's contract BEFORE touching code
Locate and read, up front: `AGENTS.md`, `CLAUDE.md`, `.hermes.md`,
`opencode.json`, `.cursorrules`, and any README/SETUP conventions. These commonly
contain MANDATORY rules that override your defaults, e.g.:
- A "zero-destruction" / "never run git checkout/reset/stash" rule.
- A banned command or a required physical-backup-before-change gate.
- The exact build/verify commands (often NOT the framework default — e.g. this
  repo uses `node scripts/build.mjs`, not bare `vite build`).
- A UI-generation skill-router rule requiring you to load design skills first.
- "Never launch the app manually for testing — use Probe MCP."

If a contract file (e.g. opencode.json) itself points at other instruction files,
read THOSE too. Skipping this step is the single most common failure mode and the
user will notice immediately.

### 2. Refactor nav/routing by nesting in the data model, not by rerouting
When the ask is "make X a sub-page of Y", first ASK or confirm the SHAPE the user
wants, because "subpage" is ambiguous and the two readings are very different:

- **IN-PAGE TAB (the usual meaning — "it should appear INSIDE the page, not on the
  side nav").** Remove X from the sidebar/rail entirely, and add it as a real tab
  inside Y's existing in-page tab bar (e.g. ActivityPage's apps/websites/productivity/
  focus tabs, InsightsPage's Day/Weekly/Activity tabs, SettingsPage's category/colors/
  .../devices tabs). Mount `<XPage />` inside an `{activeTab === 'x' && (...)}` block.
  Keep X's standalone `<Route path="/x">` registered so bookmarks/⌘K/legacy links still
  work. THIS is what "subpage" means in this app — NOT a sidebar dropdown.
- **SIDE-BAR DROPDOWN (rarely wanted).** Keep X in the sidebar but render it as a
  collapsible child under Y. See the `references/safe-nav-nesting.md` pattern. The user
  has explicitly rejected this shape ("the dropdown stuff is just stupid... it should
  NOT appear on the side navigation") — do not default to it.

Whichever shape: keep ALL existing routes registered exactly as-is (every `<Route
path=...>`, deep link, and command-palette target keeps working). Change ONLY the menu's
data model. Reuse the existing navigation/unsaved-changes guard. Leave any nested item
OUT of drag-to-reorder (which keys by top-level path) so the DnD arrayMove logic keeps
working.

This gives the visual restructure the user asked for with zero route breakage.

### 2b. React Router crash trap when wiring nav click handlers
A `navigate()` call fed a DOM event (instead of a path string) throws
`TypeError: Converting circular structure to JSON` because React Router tries to
`JSON.stringify` the event/element. This happens when you write `onClick={onNavigate}`
where `onNavigate` is the handler — React passes the `MouseEvent` as the first arg, so
the path becomes a DOM node. ALWAYS call with no arg or an explicit string:
`onClick={() => onNavigate()}` (falls back to the item's path) or
`onClick={() => onNavigate(child.path)}`. Verify there are NO raw `onClick={handler}`
bindings on elements that feed `navigate()`/`resolveTo()`.

### 3. Verify with the project's mandated build
Run the repo's actual build/verify command (from step 1). Do not assume
`vite build`/`tsc`/framework default is correct. Confirm the artifacts are valid
before declaring done (dist/index.html present with a `#root` mount + hashed JS
bundle > 10KB; preload/main entrypoints present if it's an Electron app).

If the contract forbids manually launching the app, do NOT `npx electron .` to
"test" — note "NOT LAUNCHED" and rely on the build + bundle checks.

## Pitfalls
- **Editing before reading the contract.** Invariably violates a rule the user
  cares about. "read the opencode.json instructions first" is the canonical
  correction.
- **Rerouting/renaming paths when only a menu reshuffle was wanted.** Breaks every
  deep link, bookmark, and component that references the old path. Nest in the data
  model instead.
- **Declaring success on source-only changes.** A clean diff is not a working
  feature — run the build and check the dist artifacts.
- **Building a sidebar DROPDOWN when the user said "subpage".** The user means an
  IN-PAGE tab, not a collapsible sidebar group. "the dropdown stuff is just stupid...
  it should NOT appear on the side navigation" is the canonical rejection. Remove the
  item from the sidebar and add it as a tab inside the parent page's own tab bar.
- **`onClick={onNavigate}` passing a DOM event into `navigate()`.** React passes the
  `MouseEvent` as the first arg, so `navigate(event)` tries to `JSON.stringify` a DOM
  node → `Converting circular structure to JSON`. Always bind
  `onClick={() => onNavigate()}` (no arg = falls back to item path) or
  `onClick={() => onNavigate(child.path)}` (explicit string). This crash fires on
  EVERY page that uses the handler, not just the one you edited.
- **Build output swallowed by a pipe.** In this project's non-tty bash, piping the
  build through `| tail` prints `bash: no job control in this shell` and hides the
  real exit code. Redirect to a file and echo the code instead:
  `node scripts/build.mjs > /tmp/buildlog.txt 2>&1; echo "EXIT=$?"`. Also note the
  build script uses a lockfile — a second concurrent run reports
  `Build already in progress (PID X)`; wait for the first to finish rather than
  spawning another. A stale lock file (`.build-lock`) with a dead PID in it will also
  block the build — if `pgrep` is unavailable, use `tasklist.exe`/Task Manager to
  confirm the PID is dead, then `rm -f .build-lock`. Kill only processes you started.
- **`write_file` on large TSX files is catastrophic** — `write_file` replaces the ENTIRE file. On files like `App.tsx` (~3,700 lines), a single `write_file` with empty/stale content nukes the whole file. Always use `patch` for surgical edits. If corrupted, restore immediately with `git checkout HEAD -- <file>`.
- **Old JSX blocks must be fully removed** — When replacing a component's JSX with a new one, every fragment of the old code (DOM, DnD, animations) must be deleted. Leaving even one block creates duplicate renders or JSX structure errors.

## References
- `references/safe-nav-nesting.md` — concrete React Router (HashRouter) pattern for
  nesting sidebar sub-items while preserving every route, drawn from a verified
  App.tsx refactor.
