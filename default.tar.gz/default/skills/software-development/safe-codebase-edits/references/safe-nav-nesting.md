# Nesting sidebar sub-items while preserving every route (React Router, HashRouter)

Verified pattern from a real App Tracker (Electron + React + TypeScript) refactor
where the user asked: "Rankings → sub-page of Insights", "External → sub-page of
Activity", "Database → sub-page of Settings". Outcome: visual restructure only,
zero routes broken, build green.

## The setup
- Navigation is a flat `DEFAULT_SIDEBAR_ITEMS` array: `{ icon, label, path }[]`.
- Rendering is a DnD `SortableContext` keyed by `item.path` with `arrayMove` reorder.
- Routing is separate: a `<Routes>` block with `<Route path="/rankings" .../>`
  etc. (HashRouter, so `location.pathname` is the path after `#`).
- A `handleSidebarNavigation(path)` wrapper applies the "unsaved Settings changes"
  guard before `navigate(path)`.

## The change (data model only + one component)
1. Add optional `children: { icon, label, path }[]` to parent items:
   - `/activity` → children `[{ icon: Clock4, label: 'External', path: '/external' }]`
   - `/reports`  → children `[{ icon: Trophy, label: 'Rankings', path: '/rankings' }]`
   - `/settings` → children `[{ icon: Database, label: 'Database', path: '/database' }]`
   Remove the three items from the top level. (The `SidebarItem` type is inferred
   from the array, so `children` becomes a valid field automatically.)
2. In the sidebar item component, add an expandable child list:
   - `hasChildren = Array.isArray(item.children) && item.children.length > 0`
   - `open = expanded || isChildActive` where `isChildActive` checks the current
     path (= the hash path) against each child's `path`.
   - Parent row: clicking toggles `expanded` if already active, else navigates to
     parent. Show a `ChevronDown` that rotates when `open`.
   - Child row: a nested button calling `onNavigate(child.path)` (reuses the same
     unsaved-changes guard). Highlight child when its path is active.
   - Parent highlight = active itself OR a child is active.
   - Children are intentionally NOT draggable (DnD keys on top-level `path` only).
3. Update the render call: `onNavigate={(path?: string) => handleSidebarNavigation(path ?? item.path)}`
   so child clicks forward their path through the same guard.
4. Collapsed sidebar: render just the parent icon (children reachable via ⌘K
   palette / direct URL).

## What was NOT touched (this is the whole point)
- Every `<Route path="/rankings"|"/external"|"/database" .../>` stays registered
  exactly as before. Deep links, bookmarks, the command palette, and in-app links
  all keep working.

## Build/verify
- This repo's mandated build: `node scripts/build.mjs` (NOT bare `vite build`).
  It runs 4 steps: renderer → preload → services → main. All must exit 0.
- Caveat: piping build output through `| tail` in the non-tty bash prints
  `bash: no job control in this shell` and hides the real exit code. Instead:
  `node scripts/build.mjs > /tmp/buildlog.txt 2>&1; echo "EXIT=$?"`.
- The build uses a lockfile: a second concurrent run reports
  `Build already in progress (PID X)` — wait for the first to finish.
- Circular-dependency warnings in the log (recharts/d3/mermaid) are pre-existing
  third-party noise, not from the change.
- Could not visually launch the app (contract forbids manual launch; no Probe
  session) → relied on clean build + valid dist artifacts (index.html with `#root`,
  hashed JS bundle > 10KB, main.cjs + preload.cjs present).
