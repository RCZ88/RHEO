---
id: spec-driven-implementation
name: spec-driven-implementation
category: software-development
version: 1.0.0
created: 2026-08-31
author: hermes-curator
license: MIT
description: Implement a spec directly; skip the prompt-relay stop.
tags: [implementation, relay-skill, no-questions, commit-scoping, cross-tree-bridge]
applicable_to: [feature-build, bug-fix, refactor, spec-implementation]
metadata:
  hermes:
    tags: [implementation, relay-skill]
    related_skills: [generate-prompt, commit]
---

# Spec-Driven Implementation

Implement code directly from a summarized spec, session transcript, or context doc the
user provides — without treating the repo's prompt-generation relay skill as a mandatory
stopping point. Ground every claim in the ACTUAL codebase before writing.

## When to Use
- User hands you a doc/transcript and says "implement", "fix", "wire up", "connect", or
  references a previous session and wants the change made now.
- User says "generate the prompt" / "use the skill" but ALSO clearly wants the work done.
- A repo's AGENTS.md mandates a `generate-prompt` (Architect→implementer) relay skill, but
  the user wants the actual fix, not just a design brief for another AI.

## When this skill applies
- User hands you a doc/transcript and says "implement", "fix", "wire up", "connect", or
  references a previous session and wants the change made.
- User says "generate the prompt" / "use the skill" but ALSO clearly wants the work done.
- A repo's AGENTS.md mandates a `generate-prompt` (Architect→implementer) relay skill.

## Core workflow
1. **Ground in real code first.** Read the actual files the spec mentions. Chat/session
   summaries are often STALE — verify paths, function names, and IPC channels exist before
   trusting them. (A prior session's "fix" referenced a different repo's `build-main.mjs`.)
2. **Decide implement vs. prompt.** If the user says "implement/fix", IMPLEMENT directly.
   Generate the mandated prompt docs (CONTEXT_BUNDLE.md / PROMPT.md) only as supporting
   artifacts, not as a gate you wait behind. The relay skill is a PLANNING artifact; it does
   not replace doing the work.
3. **Proceed; don't loop on questions.** When context is already provided (summarized spec,
   transcript), state your assumptions as decisions ("I'll scope the commit to my 11 files")
   and build. Only surface a real blocker as a stated decision, not a question.
4. **Verify with the build**, then commit and push per the repo's commit skill.

## Hard rules learned from this user (embedded as preferences)
- **Motion over Q&A.** This user explicitly said: when in doubt, produce the artifact
  (prompt) rather than ask; and when they say "implement the full spec fix", they mean DO
  IT — not "here is a prompt for another AI." Implement directly.
- **Don't get stuck in the relay.** Mandated `generate-prompt` skills produce a design brief
  for a separate target AI. That is useful planning context, but if the user wants the fix
  now, write the code now. You can still drop the prompt docs in the repo's
  `agent/docs/generate-prompt-docs/<name>-DDMMYYYY/` folder for traceability.

## Technique: cross-tree React bridge (no shared state)
When two feature trees live under a mode toggle (e.g. a 3-pane workspace where switching
mode just swaps the React subtree) and must hand data to each other, a React context won't
reach across. Use a **module-level event emitter**:
- Create `handoffBus.ts`: a `Set<Listener>` with `emit(payload)` / `subscribe(l)` returning
  an unsubscribe fn.
- Sender imports it and calls `studioHandoff.emit(payload)` on the action.
- Receiver (the mode host) subscribes in a `useEffect`, dispatches into its own store, and
  switches mode. This is how Content Engine's Assemble → Overlay Studio handoff was wired
  (replacing a dead `onPhaseChange('studio')` stub).

## Technique: commit scoping in a messy tree (DEVATION from repo commit skill)
The repo `agent/skills/commit/SKILL.md` says "ALWAYS `git add -A`". That is WRONG here when
the working tree has hundreds of unrelated pre-existing modified files (this repo routinely
has 900+). Staging all of them pollutes your commit with unrelated work.
- **Scope the commit to the files you actually changed** (`git add <specific files>`), plus
  the changelog (COMMITS.md) and any prompt docs you authored.
- Still follow the commit skill's other rules: exhaustive commit message covering every
  changed file, update COMMITS.md, then `git push`.
- This is a deliberate, justified deviation from the literal `git add -A` rule.

## Repo-specific quirks (see references/rheo-build-commit.md)
- Build: `npm run build` → `scripts/build.mjs`, 4 steps, has a `.build-lock` mutex; a stale
  dead-PID lock blocks builds (`rm -f .build-lock` to clear). esbuild does NOT type-check —
  run `npx eslint <touched files>` after.
- `generate-prompt` relay lives at `agent/skills/generate-prompt/SKILL.md` (project-owned;
  do not edit — recommend `hermes curator adopt` if it needs changes).
- `commit` skill lives at `agent/skills/commit/SKILL.md` (project-owned; same).
- Landing phased brief pattern: see `references/landing-takeover-checklist.md`.

## Hard rules learned from this user (embedded from session use)
- **Never silently start servers.** If the user asks "how do I start the server?", give a
  copy-paste command or script. Do not background-launch it yourself; do not treat an
  already-running port as “fine” without checking whether they actually wanted a fresh
  instance.
- **PowerShell compatibility.** `npm run dev` scripts that use `tee` fail in PowerShell.
  Either provide a `.ps1` wrapper using `Tee-Object`, or fix the npm script to be shell-
  neutral. When the user is on Windows PowerShell, prefer a `.ps1` launcher script.
- **Port conflicts.** If port 3000 is occupied, the dev server fails. The robust pattern:
  detect PID on target port, kill it, wait briefly, then start. Provide this as a script
  when the user asks how to run; do not assume they will handle the conflict manually.
- **Capture the user's intent, not just the surface request.** This session showed that the
  user expected app/desktop screenshots + recordings, not landing-page captures. When
  a deliverable is media, verify the subject before capturing: website vs. desktop app vs.
  mobile app.
- **Maintain exact checklist coverage in written artifacts.** If the task lists sub-items
  a–h, the deliverable must contain all 8 with evidence, not fewer because some were
  “referenced in analysis.” The user's "are you sure?" is a signal to audit line-by-line.
- **When asked for a script/command, deliver the script/command.** This user's context
  includes prior frustration with broken PowerShell startup; a `.ps1` that handles port
  conflicts + `tee` is the expected artifact, not a shell tutorial.

## Technique: cross-tree React bridge (no shared state)
When two feature trees live under a mode toggle (e.g. a 3-pane workspace where switching
mode just swaps the React subtree) and must hand data to each other, a React context won't
reach across. Use a **module-level event emitter**:
- Create `handoffBus.ts`: a `Set<Listener>` with `emit(payload)` / `subscribe(l)` returning
  an unsubscribe fn.
- Sender imports it and calls `studioHandoff.emit(payload)` on the action.
- Receiver (the mode host) subscribes in a `useEffect`, dispatches into its own store, and
  switches mode. This is how Content Engine's Assemble → Overlay Studio handoff was wired
  (replacing a dead `onPhaseChange('studio')` stub).

## Technique: commit scoping in a messy tree (DEVATION from repo commit skill)
The repo `agent/skills/commit/SKILL.md` says "ALWAYS `git add -A`". That is WRONG here when
the working tree has hundreds of unrelated pre-existing modified files (this repo routinely
has 900+). Staging all of them pollutes your commit with unrelated work.
- **Scope the commit to the files you actually changed** (`git add <specific files>`), plus
  the changelog (COMMITS.md) and any prompt docs you authored.
- Still follow the commit skill's other rules: exhaustive commit message covering every
  changed file, update COMMITS.md, then `git push`.
- This is a deliberate, justified deviation from the literal `git add -A` rule.

## Technique: Windows PowerShell dev-server launcher
When a Next.js landing or similar project needs a dev-server start script on Windows:
- Provide `start-dev.ps1` that kills the existing port listener, then starts `npx next dev`
  with `Tee-Object` for logging.
- Template: see `templates/start-dev.ps1`.
- User runs it with: `Set-ExecutionPolicy -Scope CurrentUser Bypass -Force; .\start-dev.ps1`

## Repo-specific quirks (see references/rheo-build-commit.md)
- Build: `npm run build` → `scripts/build.mjs`, 4 steps, has a `.build-lock` mutex; a stale
  dead-PID lock blocks builds (`rm -f .build-lock` to clear). esbuild does NOT type-check —
  run `npx eslint <touched files>` after.
- `generate-prompt` relay lives at `agent/skills/generate-prompt/SKILL.md` (project-owned;
  do not edit — recommend `hermes curator adopt` if it needs changes).
- `commit` skill lives at `agent/skills/commit/SKILL.md` (project-owned; same).
- Landing phased brief pattern: see `references/landing-takeover-checklist.md`.

## Anti-patterns
- Treating a mandated prompt-generation skill as a work stopper ("I'll just write the prompt
  and wait for a target AI") when the user said implement.
- Asking clarifying questions about context the user already summarized and handed you.
- `git add -A` in a 900-file-dirty tree.
- Trusting a session transcript's file paths without re-reading the files.
- Claiming a deliverable is complete without re-reading the written artifact against the
  original checklist. The user's "are you sure?" is a signal to audit line-by-line, not
  to defend prior claims.
- Omitting checklist items from a deliverable because they were "referenced in analysis"
  but never actually written into the file. If the task lists 8 sub-items (a–h), the
  deliverable must contain all 8 with evidence, not just 4.
- Starting servers or running commands for the user when they asked "how do I..." — give
  the runnable command/script instead.
- Claiming UI changes are applied without verifying the running server serves the updated
  code. On Next.js/Electron, stale `.next` cache or a wrong port/process will show old
  UI even after edits. After landing changes, verify with a fresh screenshot or rebuild.
- Iterating a script in 5+ rounds when the user asked for one file. Deliver one clean
  script; fix it in-place if it breaks.
