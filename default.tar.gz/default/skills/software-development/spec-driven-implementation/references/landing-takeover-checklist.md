# Landing Takeover Checklist Pattern

Use when the user hands you a phased implementation brief for a landing page or
similar UI, with explicit commit checkpoints between phases.

## Commit cadence
- Commit after each **logical phase**, not after every file.
- Scope commits to the files actually touched for that phase (`git add <specific files>`).
- Do NOT `git add -A` when the tree has many unrelated pre-existing modifications.
- Use a commit message that enumerates every file touched in that phase.

## Phase completion rule
Before declaring a phase complete, **re-read the written artifact** against the
original checklist. The user's "are you sure?" is a signal to audit line-by-line,
not to defend prior claims.

Common omission patterns:
- Checklist sub-items (a–h) referenced in analysis but never written into the deliverable.
- A "table" that is actually bullet prose (convert to real table).
- Verbatim strings that are paraphrased rather than quoted exactly.
- File/line evidence that is described but not cited with exact paths.

## Windows / Playwright specifics
- `e2e/` spec files must be created with `write_file`; `terminal cat >` heredocs
  may fail with "No such file or directory" if the directory doesn't exist.
- Playwright project must be configured (`playwright.config.ts`) before tests run;
  otherwise `--project=chromium` fails.
- `@playwright/test` must be installed in the **target project's** `node_modules`,
  not the parent repo's.
- RM media-query mocking via `page.emulateMedia` doesn't always take effect on
  reload; use `page.addInitScript` to override `window.matchMedia` before navigation.

## Token grep pattern
```bash
grep -rnE "#[0-9a-fA-F]{3,8}|rgba?\(|hsla?\(" src/ --include="*.tsx" --include="*.css" | \
  grep -v "allowed-token-patterns"
```
Whitelist spec-token values before flagging violations.

## Reduced-motion test pattern
Instead of asserting time-static behavior (which fails because the page may be
cached with non-RM media query), verify the **source gate**:
- Grep the source for both the media-query check and the conditional `return`
  that skips the interval/animation.
- Assert the source contains the gate; do not rely on runtime time-diff tests
  unless the media query mock is confirmed effective.
