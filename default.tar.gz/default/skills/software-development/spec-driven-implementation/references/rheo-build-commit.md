# RHEO (App Tracker) — build & commit reference

Condensed notes for the RHEO Electron + React + TS app at
C:\Users\cleme\Documents\COMPUTAH_SAYENCE\App Tracker.

## Build
- Command: `npm run build` → runs `scripts/build.mjs`.
- 4 steps: (1) vite renderer, (2) esbuild preload → `dist-electron/preload.cjs`,
  (3) esbuild all `src/services|domains|lib|shared|main` .ts → .js, (4) vite lib-mode
  main entry → `dist-electron/main.cjs`.
- **Build mutex:** `scripts/build.mjs` writes `.build-lock` with its PID. If a previous
  build died, a stale lock with a dead PID blocks new builds with
  "Build already in progress (PID N)". Fix: `rm -f .build-lock` then rebuild.
- esbuild does NOT type-check. After edits, run `npx eslint <touched files>` to catch
  real issues. Pre-existing `any` usage in `contentEngine/index.ts` / `preload.ts` is
  baseline — don't treat those 500+ `no-explicit-any` errors as yours.
- Don't launch Electron (AGENTS.md forbids the agent from launching it). Build-verify only.

## Commit (DEVATION from repo commit skill)
- Repo `agent/skills/commit/SKILL.md` says ALWAYS `git add -A`. The working tree here
  routinely has 900+ unrelated pre-existing modified files. Staging all of them pollutes
  the commit. Instead scope: `git add <specific files>` (your changed src + COMMITS.md +
  any prompt docs you authored). Keep the skill's other rules (exhaustive message, update
  COMMITS.md, then push).
- COMMITS.md lives at `agent/COMMITS.md` — prepend a "## Latest Commit" entry with the
  full message under "### Commit Message" fenced block.
- Commit message must be exhaustive (every changed file + why). Prefixes: feat:/fix:/chore:/.

## Prompt-relay artifacts (if the repo's generate-prompt skill is invoked)
- Folder: `agent/docs/generate-prompt-docs/<descriptive-name>-DDMMYYYY/`
  (date WITHOUT separators).
- Write `CONTEXT_BUNDLE.md` (code/IPC/DB reference) + `PROMPT.md` (design brief). These are
  supporting artifacts — they do NOT replace implementing the fix when the user said "implement".
