$ErrorActionPreference = 'Stop'
$script:PORT = 3000
$script:DIR   = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:LOG   = Join-Path $DIR 'dev.log'

function Write-Step($msg) { Write-Host "== $msg ==" -ForegroundColor Cyan }

Write-Step "Checking port $PORT"
$existing = Get-NetTCPConnection -LocalPort $PORT -ErrorAction SilentlyContinue |
            Select-Object -ExpandProperty OwningProcess -Unique
if ($existing) {
  Write-Step "Killing PID(s): $($existing -join ', ')"
  foreach ($pid in $existing) {
    Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
  }
  Start-Sleep -Milliseconds 300
}

Write-Step "Starting dev server on port $PORT"
Set-Location $DIR
$env:PORT = "$PORT"
npx next dev -p $PORT *>&1 | Tee-Object -FilePath $LOG
